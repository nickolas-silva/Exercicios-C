#include <iostream>
using namespace std;

struct Controller
{
	char name[40];
	int buttons;
	int axis;
};
// --------------------------------
// crie aqui as fun��es para listar
// --------------------------------
void ListarNomes(Controller x)
{
	cout << x.name << "\t";
	
}
void ListarEixos(Controller y)
{
	cout << y.buttons << " " << y.axis << "\t";
}
void Enumerate(void(*f)(Controller))
{
	Controller vet[] =
	{
	{"Joy", 8, 4},
	{"Xbox", 10, 3},
	{"Play", 8, 6}
	};
	for (auto i : vet)
		f(i);
	
}
int main()
{

	Enumerate(ListarNomes);
	cout << endl;
	Enumerate(ListarEixos);
}
