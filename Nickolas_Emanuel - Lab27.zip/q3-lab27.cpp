#include <iostream>
using namespace std;

void (*OnClick)(void);
// -------------------------------
// crie aqui a fun��o CreateButton
// -------------------------------
void CreateButton(int n1, int n2, void(*f)(void))
{
	cout << "Botao criado na posicao " << n1 << ", " << n2 << ". \n";
	OnClick = f;
}
void Mensagem()
{
	cout << "Bot�o Pressionado!" << endl;
}
int main()
{
	CreateButton(10, 10, Mensagem);
	// simulando pressionamento
	cout << "Pressionar Bot�o? ";
	char resposta;
	cin >> resposta;
	if (resposta == 'S' || resposta == 's')
		OnClick();
	
}