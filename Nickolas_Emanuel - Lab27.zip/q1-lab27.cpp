#include <iostream>
using namespace std;

int menu(void);
void func0(void);
void func1(void);
void func2(void);
void func3(void);
void (*func[])(void) = { func0, func1, func2, func3 };


int main()
{
	
	int escolha = 0;
	while (escolha != 4)
	{
		escolha = menu();
		switch (escolha)
		{
		case 1: func[0]();
			break;
		case 2: func[1]();
			break;
		case 3: func[2]();
			break;
		case 4: func[3]();
			break;
		}
	}
}
int menu(void)
{
	int num;
	cout << "Menu do Sistema\n";
	cout << endl;
	cout << "1) Inserir\n" << "2) Remover\n" << "3) Buscar\n" << "4) Sair\n";
	cin >> num;
	return num;
}
void func0(void)
{
	cout << "Voce escolheu INSERIR.\n";
}
void func1(void)
{
	cout << "Voce escolheu REMOVER.\n";

}
void func2(void)
{
	cout << "Voce escolheu BUSCAR.\n";
}
void func3(void)
{
	cout << "Voce escolheu SAIR.\n";
}