#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <string>

using namespace std;

struct conta
{
	char nome[40];
	float saldo;

};
int main()
{
	conta usuario;
	char n[20];
	cout << "Entre com seu nome para criar uma conta: ";
	cin >> n;
	cout << endl;

	strcpy(usuario.nome, n);
	usuario.saldo = 0;
	

	cout << "Conta criada" << endl << "-------------" << endl;
	cout << "Usuario: " << usuario.nome << endl << "Saldo: " << usuario.saldo << endl;

	float deposito;
	cout << "Quanto deseja depositar? ";
	cin >> deposito;
	usuario.saldo = deposito;
	cout << endl;

	cout << "Seu saldo foi atualizado! " << endl << "Saldo atual: R$" << usuario.saldo;
}