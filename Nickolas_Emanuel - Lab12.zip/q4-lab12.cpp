#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
using namespace std;

struct livro
{
	char nome[20];
	float valor;
};
struct jogo
{
	char nome[20];
	float valor;
};
int main()
{
	jogo jgemp[5];
	livro lemp[5];

	int escolha;
	cout << "Deseja adicionar um livro ou um jogo?" << endl << "Digite 0 para adicionar um livro ou 1 para adicionar um jogo" << endl;
	cin >> escolha;

	if (escolha == 0)
	{
		
		cout << "Digite o nome do livro: ";
		cin >> lemp[0].nome;
	
		
		cout << "Digite o valor do livro: ";
		cin >> lemp[0].valor;
		system("cls");
		cout << "Novo livro adicionado!" << endl;
		cout << "O livro " << lemp[0].nome << " custa R$ " << lemp[0].valor << endl;
	}
	else
	{
		cout << "Digite o nome do jogo: ";
		cin >> jgemp[0].nome;
		cout << "Digite o valor do jogo: ";
		cin >> jgemp[0].valor;
		system("cls");
		cout << "Novo jogo adicionado!" << endl;
		cout << "O jogo " << jgemp[0].nome << " custa " << "R$ " << jgemp[0].valor << endl;
	}
}