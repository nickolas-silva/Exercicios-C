#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
using namespace std;


struct conta
{
	char nome[20];
	float saldo;
};

void exibirconta(conta);
struct pal
{
	char portugues[20];
	char espanhol[20];
	char ingles[20];
};

void exibir(pal []);

int main()
{
	conta usuario;
	char n[20];
	cout << "Entre com seu nome para criar uma conta: ";
	cin >> n;
	cout << endl;

	strcpy(usuario.nome, n);
	usuario.saldo = 0;


	cout << "Conta criada" << endl << "-------------" << endl;
	cout << "Usuario: " << usuario.nome << endl << "Saldo: " << usuario.saldo << endl;

	float deposito;
	cout << "Quanto deseja depositar? ";
	cin >> deposito;
	usuario.saldo = deposito;
	cout << endl;

	cout << "Seu saldo foi atualizado! " << endl;
	
	exibirconta(usuario);
	system("pause");
	system("cls");

	pal dicionario[10] = { "Amor", "Joelho" };
	strcpy(dicionario[0].portugues, "Amor");
	strcpy(dicionario[0].espanhol, "Amor");
	strcpy(dicionario[0].ingles, "Love");
	strcpy(dicionario[1].portugues, "Joelho");
	strcpy(dicionario[1].espanhol, "Rodilla");
	strcpy(dicionario[1].ingles, "Knee");

	char plv[20], epl[20], ipl[20];
	cout << "Digite uma palavra para adicionar no dicionario: ";
	cin >> plv;
	strcpy(dicionario[2].portugues, plv);

	cout << "Em espanhol: ";
	cin >> epl;
	strcpy(dicionario[2].espanhol, epl);

	cout << "Em ingles: ";
	cin >> ipl;
	strcpy(dicionario[2].ingles, ipl);
	

	cout << "Dicionario completo:" << endl;
	cout << "--------------------" << endl;
	exibir(dicionario);
}
void exibirconta(conta usuario)
{
	cout << "Dados da conta\n";
	cout << "---------------" << endl;
	cout << "Nome do usuario: " << usuario.nome << endl;
	cout << "Saldo: " << usuario.saldo << endl;
}
void exibir(pal dic[9])
{
	int escolha;
	cout << "Escolha uma palavra para exibir:" << endl;
	cout << "0, 1 ou 2? ";
	cin >> escolha;
	cout << "Palavra: " << dic[escolha].portugues << endl;
	cout << "Em espanhol: " << dic[escolha].espanhol << endl;
	cout << "Em ingles: " << dic[escolha].ingles << endl;
	cout << endl;

	

	
}