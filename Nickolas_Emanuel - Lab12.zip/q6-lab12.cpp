#include <iostream>
using namespace std;

struct horario
{
	int hora;
	int min;
};
int lerh(void);
int lerm(void);
void exibir(int);
int conta(int, int);

int main()
{
	horario inicio;
	horario final;

	int horai, mini, horaf, minf;
	char pontos;

	cout << "Inicio: ";
	horai = lerh();
	cin >> pontos;
	mini = lerm();
	inicio.hora = horai;
	inicio.min = mini;

	cout << "Final: ";
	horaf = lerh();
	cin >> pontos;
	minf = lerm();
	final.hora = horaf;
	final.min = minf;
	
	int mint = ((conta(horaf, minf)) - (conta(horai, mini)));
	cout << "Entre " << inicio.hora << ":" << inicio.min << " e " << final.hora << ":" << final.min << " existem " << mint << " minutos, isto e, " << (mint / 60) << "h e " << (mint % 60) << "minutos";


}
int lerh(void)
{
	int h;
	cin >> h;
	return h;
}
int lerm(void)
{
	int m;
	cin >> m;
	return m;
}
void exibir(int a)
{
	cout << a;
}
int conta(int a, int b)
{
	int minutos;
	a = (a * 60);
	minutos = a + b;
	return minutos;
}
