#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
using namespace std;

struct palavra
{
	char portugues[20];
	char espanhol[20];
	char ingles[20];
};
int main()
{
	palavra dicionario[10] = { "Amor", "Joelho" };
	strcpy(dicionario[0].portugues, "Amor");
	strcpy(dicionario[0].espanhol, "Amor");
	strcpy(dicionario[0].ingles, "Love");
	strcpy(dicionario[1].portugues, "Joelho");
	strcpy(dicionario[1].espanhol, "Rodilla");
	strcpy(dicionario[1].ingles, "Knee");

	char plv[20], epl[20], ipl[20];
	cout << "Digite uma palavra para adicionar no dicionario: ";
	cin >> plv;
	strcpy(dicionario[2].portugues, plv);

	cout << "Em espanhol: ";
	cin >> epl;
	strcpy(dicionario[2].espanhol, epl);

	cout << "Em ingles: ";
	cin >> ipl;
	strcpy(dicionario[2].ingles, ipl);
	system("pause");
	system("cls");

	cout << "Dicionario completo:" << endl;
	cout << "--------------------" << endl;

	cout << "Palavra: " << dicionario[0].portugues << endl;
	cout << "Em espanhol: " << dicionario[0].espanhol << endl;
	cout << "Em ingles: " << dicionario[0].ingles << endl;
	cout << endl;

	cout << "Palavra: " << dicionario[1].portugues << endl;
	cout << "Em espanhol: " << dicionario[1].espanhol << endl;
	cout << "Em ingles: " << dicionario[1].ingles << endl;
	cout << endl;

	cout << "Palavra: " << dicionario[2].portugues << endl;
	cout << "Em espanhol: " << dicionario[2].espanhol << endl;
	cout << "Em ingles: " << dicionario[2].ingles << endl;
	cout << endl;



	
}