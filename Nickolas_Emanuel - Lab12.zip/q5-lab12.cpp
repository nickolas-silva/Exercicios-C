#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
using namespace std;

struct dma
{
	short dia;
	short mes;
	short ano;
};
struct horario
{
	short hora;
	short min;
	short seg;
};
struct evento
{
	dma dia;
	horario horario;
	char local[40];

};
int main()
{
	evento x;
	char pontos;

	cout << "Entre com a data do evento:";
	cin >> x.dia.dia >> pontos >> x.dia.mes >> pontos >> x.dia.ano;
	
	cout << "Entre com o horario do evento;";
	cin >> x.horario.hora >> pontos >> x.horario.min >> pontos >> x.horario.seg;
	cin.get();

	cout << "Entre com o local do evento: ";
	cin >> x.local;

	cout << "O evento acontecera no " << x.local << " as " << x.horario.hora << ":" << x.horario.min << ":" << x.horario.seg
		<< " do dia " << x.dia.dia << "/" << x.dia.mes << "/" << x.dia.ano;
}