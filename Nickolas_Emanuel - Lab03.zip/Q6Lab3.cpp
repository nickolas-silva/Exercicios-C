#include <iostream>
using namespace std;

int main(void)
{
	float ladoa, ladob, altura, volume;

	cout << "Lado a: ";
	cin >> ladoa;


	cout << "Lado b: ";
	cin >> ladob;

	cout << "Area da base = " << (ladoa * ladob) << endl;

	cout << "Altura: ";
	cin >> altura;

	volume = (ladoa * ladob * altura);
	cout << "Volume do prisma = " << volume;

}
