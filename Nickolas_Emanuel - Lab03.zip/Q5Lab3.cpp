#include <iostream>
using namespace std;

int main(void)
{
	int horas, mins;
	char pontos;

	cout << "Que horas sao?";
	cin >> horas;
	cin >> pontos;
	cin >> mins;

	cout << "Seu relogio esta atrasado." << endl;
	cout << "Agora sao " << (horas + 1) << ":" << mins << endl;


}