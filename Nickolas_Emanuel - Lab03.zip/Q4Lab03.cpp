#include <iostream>
using namespace std;

int main(void)
{
	float valor;

	cout << "Pre�o de fabrica: ";
	cin >> valor;

	float valorf;

	valorf = (valor * 1.73);
	cout << "O custo ao consumidor � de R$" << valorf << endl;


}