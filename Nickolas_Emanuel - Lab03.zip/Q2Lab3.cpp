#include <iostream>
using namespace std;

int main(void)
{
	cout << "Tabuada de n" << endl;
	cout << "------\n";

	int numero;
	cout << "Entre com um n�mero n (0 a 9): ";
	cin >> numero;
	cout << numero << " x " << "0 = " << (numero * 0) << endl;
	cout << numero << " x " << "1 = " << (numero * 1) << endl;
	cout << numero << " x " << "2 = " << (numero * 2) << endl;
	cout << numero << " x " << "3 = " << (numero * 3) << endl;
	cout << numero << " x " << "4 = " << (numero * 4) << endl;
	cout << numero << " x " << "5 = " << (numero * 5) << endl;
	cout << numero << " x " << "6 = " << (numero * 6) << endl;
	cout << numero << " x " << "7 = " << (numero * 7) << endl;
	cout << numero << " x " << "8 = " << (numero * 8) << endl;
	cout << numero << " x " << "9 = " << (numero * 9) << endl;




}