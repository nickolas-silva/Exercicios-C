#include <iostream>
using namespace std;

int main(void)
{
	float tempcicl, tempco, tempna;
	int hcicl, hco, hna;
	int mcicl, mco, mna;
	int kg;

	cout << "Digite seu peso em quilos: " << endl;
	cin >> kg;

	char letras;

	cout << "Digite o tempo de corrida: " << endl;
	cin >> hco;
	cin >> letras;
	cin >> mco;
	cin >> letras;

	cout << "Digite o tempo de ciclismo: " << endl;
	cin >> hcicl;
	cin >> letras;
	cin >> mcicl;
	cin >> letras;

	cout << "Digite o tempo de nata��o: " << endl;
	cin >> hna;
	cin >> letras;
	cin >> mna;
	cin >> letras;

	tempco = (hco * 60 + mco);
	tempcicl = (hcicl * 60 + mcicl);
	tempna = (hna * 60 + mna);

	float eco, ecicl, ena, e;
	eco = (7 * kg * (tempco/60));
	ecicl = (7 * kg * (tempcicl/60));
	ena = (8 * kg * (tempna/60));

	e = (eco + ecicl + ena);

	cout << "Voc� gastou um total de " << e << " calorias.";
	




}