#include <iostream>
using namespace std;

int main(void)
{
	int anos, cigarros, carteiras;
	
	cout << "A quantos anos voc� fuma? ";
	cin >> anos;

	cout << "Quantos cigarros voc� fuma por dia? ";
	cin >> cigarros;

	float valor, valorf;

	cout << "Qual o valor m�dio de uma carteira com 20 cigarros? ";
	cin >> valor;

	carteiras = (anos * 365) / (20 / cigarros);
	valorf = (carteiras * valor);

	cout << "Ate agora foi gasto o total de R$" << valorf << " com cigarros." << endl;

}