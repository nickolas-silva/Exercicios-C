#include <iostream>
using namespace std; 

int main()
{
	int x, y, quociente;
	//Entrada dos n�meros inteiros
	cout << "Digite dois numeros inteiros: " << endl;
	cin >> x >> y;

	//Conta para achar o quociente
	quociente = x / y;

	//Saida do programa
	cout << "O quociente " << x << "/" << y << " = " << quociente << endl;
	cout << "O resto da divis�o " << x << "%" << y << " = " << (x % y);



}