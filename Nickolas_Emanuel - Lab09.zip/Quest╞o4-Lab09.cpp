#include <iostream>
using namespace std;

int main()
{
	//Entrada da dist�ncia 
	int dist, distt;
	int km, m;

	cout << "Entre com a distancia em metros: ";
	cin >> dist;

	//Conta para mostrar os quil�metros e os metros correspondentes a dist�ncia informada
	km = (dist / 1000);
	m = (dist % 1000);

	//Saida do programa
	cout << dist << " metros equivalem a " << km << " quilometros e " << m << " metros";

}