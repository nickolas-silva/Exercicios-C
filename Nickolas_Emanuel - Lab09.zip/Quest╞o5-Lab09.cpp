#include <iostream>
using namespace std;

int main()
{
	//Defini��o das variaveis
	double x = 245.795;
	int y;
	y = x;

	//Multiplicando as duas por 100
	cout << (x * 100) << endl;
	cout << (y * 100) << endl;

	//Pode-se concluir que � necess�rio tomar cuidado ao fazer essas convers�es de tipos de vari�veis.
	//Pois alguns valores podem ser modificados podendo afetar o resultado final do programa. 
	//Nesse caso x e y foram multiplicados pelo mesmo numer mas seus resultado foram completamente diferentes pelo fato do y conter apenas a parte antes da virgula de x.

 
}