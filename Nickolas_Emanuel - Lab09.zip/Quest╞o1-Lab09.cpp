#include <iostream>
using namespace std;

int main()
{
	int a, b, c;
	a = 1 + 2; // linha 1 a = 3 / b = ainda n�o foi inicializada / c = ainda n�o foi inicializada
	b = 1 + a; // linha 2 a = 3 / b = 4 / c = ainda n�o foi inicializada
	c = 1 % 5; // linha 3 a = 3 / b = 4 / c = 1
	a = a + 2; // linha 4 a = 5 / b = 4 / c = 1
	b = a - c; // linha 5 a = 5 / b = 4 / c = 1
	b = 5 * c / 2; // linha 6 a = 5 / b = 2(se b fosse double b seria 2.5) / c = 1
}