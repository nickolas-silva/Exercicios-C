#include <iostream>
using namespace std;

int main()
{
	//declara��o de variaveis
	double real, fracionaria;
	int inteira;

	//Entrada do numero
	cout << "Digite um n�mero real: ";
	cin >> real;

	//Convers�o de tipos para mostrar apenas a parte inteira
	inteira = real;
	//Saida da parte inteira
	cout << "A parte inteira: " << inteira << endl;
	//Conta para mostrar apenas a parte depois da virgula
	fracionaria = (real - inteira);
	cout << "A parte fracionaria: " << fracionaria;


}