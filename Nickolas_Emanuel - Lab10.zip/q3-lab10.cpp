#include <iostream>
using namespace std;
double funcao(double[]);

int main()
{
	double vet[3];

	cout << "Digite o valor para as 3 posicoes do vetor: \n";
	cin >> vet[0];
	cin >> vet[1];
	cin >> vet[2];

	cout << "O resultado da mult entre o primeiro e o ultimo menos o termo do meio e = " << funcao(vet);


}
double funcao(double vet[])
{
	double result;
	result = ((vet[0] * vet[2]) - vet[1]);
	return result;
}