#include <iostream>
using namespace std;
void linhas(void);

int main()
{
	srand(time(NULL));
	int numeros[5] = { rand() % 1000, rand() % 1000, rand() % 1000, rand() % 1000, rand() % 1000 };
	cout << "Vetor: " << numeros[0] << " " << numeros[1] << " " << numeros[2] << " " << numeros[3] <<
		" " << numeros[4] << endl;
	linhas();
	cout << endl;

	int posicao, valornovo;
	cout << "Alterar posicao: ";
	cin >> posicao;
	cout << "Novo valor: ";
	cin >> valornovo;
	
	linhas();
	cout << endl;

	numeros[posicao] = valornovo;

	cout << "Vetor: " << numeros[0] << " " << numeros[1] << " " << numeros[2] << " " << numeros[3]
		<< " " << numeros[4];



	
}
void linhas(void)
{
	cout << "-------------------------";
}