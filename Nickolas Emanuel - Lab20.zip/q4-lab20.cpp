#include <iostream>
using namespace std;

int main()
{
	int num1, num2;
	int soma = 0;
	int i;
	cout << "Digite um numero inteiro: ";
	cin >> num1;
	cout << "Digite outro numero inteiro: ";
	cin >> num2;

	if (num1 == num2)
		cout << "A soma de todos os elementos entre " << num2 << " e " << num1 << ": 0";
	if (num1 < num2)
	{
		for (i = (num1 + 1); i < (num2); i++)
		{
			soma += i;
		}
		cout << "A soma de todos os elementos entre " << num1 << " e " << num2 << ": " << soma;
	}
	if (num1 > num2)
	{
		for (i = (num2 + 1); i < (num1); i++)
		{
			soma += i;
		}
		cout << "A soma de todos os elementos entre " << num2 << " e " << num1 << ": " << soma;
	}
}
























	