#include <iostream>
using namespace std;

int main()
{
	cout << "Quantos KM a viagem possui? ";
	int km, custo = 0;
	cin >> km;

	if (km <= 200)
	{
		custo = (km * 0.50);
	}
	else if (km <= 400)
	{
		custo = (km * 0.40);
	}
	else if (km > 400)
	{
		custo = (km * 0.30);
	}
	cout << "O preco da viagem sera de: R$" << custo;
}