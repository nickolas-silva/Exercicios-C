#include <iostream>
using namespace std;

int main()
{
	int vel[10];
	int cont = 0;
	int multat = 0;
	cout << "As ultimas 10 velocidades registradas: " << endl;
	for (int i = 0; i < 10; i++)
		cin >> vel[i];
	cout << endl;
	for (int j = 0; j < 10; j++)
	{
		if (vel[j] > 80)
		{
			cout << vel[j] << " Km/h excede o limite = multa de R$" << ((vel[j] - 80) * 8) << endl;
			cont++;
			multat += ((vel[j] - 80) * 8);
		}
	}
	cout << endl;
	cout << cont << " carros foram multados em um valor de R$" << multat;

}