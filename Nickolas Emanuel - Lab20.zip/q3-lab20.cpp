#include <iostream>
using namespace std;

int main()
{
	char ch;
	int mod=0;

	cout << "Digite um texto (# para finalizar)\n";

	ch = cin.get();
	while (ch != '#')
	{

		if (ch == '!')
		{
			cout << ch;
			mod++;

		}
		if (ch == '.')
		{
			ch -= 13;
			mod++;
		}
	
		
		cout << ch;
		cin.get(ch);

	}
	cout << endl << endl;
	cout << "Substituicoes: " << mod;
}