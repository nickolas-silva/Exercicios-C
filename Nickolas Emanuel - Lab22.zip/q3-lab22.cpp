#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
using namespace std;
void cardapio(void);

struct Prato
{
	float preco;
	char nome[20];
};
int main()
{
	float pedido= 0;
	int escolha;
	Prato vet[3];
	strcpy(vet[0].nome, "Parmegiana");
	vet[0].preco = 32;

	strcpy(vet[1].nome, "Pizza G");
	vet[1].preco = 35;

	strcpy(vet[2].nome, "Macarronada");
	vet[2].preco = 27.50;

	cardapio();
	cout << "Deseja pedir o prato 1,2 ou 3? 4 para sair!";
	cin >> escolha;
	while (escolha != 4)
	{
		switch (escolha)
		{
		case 1: cout << "Voce pediu uma Parmegiana. Bom Apetite!\n";
			pedido += 32;
			break;
		case 2:cout << "Voce pediu uma Pizza G. Bom Apetite!\n";
			pedido += 35;
			break;
		case 3:cout << "Voce pediu uma Macarronada. Bom Apetite!\n";
			pedido += 27.50;
			break;
		default: break;
		}
		system("pause");
		system("cls");
		cardapio();
		cout << "Deseja pedir o prato 1,2 ou 3? 4 para sair!";
		cin >> escolha;
	}
	cout << "VALOR DO PEDIDO TOTAL: R$" << pedido;
}
void cardapio(void)
{
	cout << "PRATOS" << endl;
	cout << "----------" << endl;
	cout << "1� Parmegiana__________________________R$ 32,00" << endl;
	cout << "2� Pizza G_____________________________R$ 35,00" << endl;
	cout << "3� Macarroanda_________________________R$ 27,50" << endl;
}