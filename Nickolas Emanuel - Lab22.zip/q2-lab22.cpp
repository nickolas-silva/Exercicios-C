#include <iostream>
using namespace std;

int main()
{
	char ch;
	int conta = 0;
	int conte = 0;
	int conti = 0;
	int conto = 0;
	int contu = 0;

	cout << "Digite uma frase (@ para finalizar):" << endl;
	do
	{
		cin.get(ch);
		switch (ch)
		{
		case 'A':
		case 'a': conta++;
			break;

		case 'E':
		case 'e': conte++;
			break;

		case 'I':
		case 'i': conti++;
			break;
		case 'O':
		case 'o': conto++;
			break;

		case 'U':
		case 'u': contu++;
			break;
		}
	} while (ch != '@');

	cout << "a: " << conta << endl;
	cout << "e: " << conte << endl;
	cout << "i: " << conti << endl;
	cout << "o: " << conto << endl;
	cout << "u: " << contu << endl;
	
		
}