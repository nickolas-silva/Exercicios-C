#include <iostream>
using namespace std;

int main()
{
	int preco, cod;
	cout << "Digite o preco do produto: ";
	cin >> preco;
	cout << "Digite o codigo de origem do produto: ";
	cin >> cod;

	switch (cod)
	{
	case 1:
	case 2: cout << "O produto tem procedencia: Sul";
		break;
	case 3: cout << "O produto tem procedencia: Norte";
		break;
	case 4: cout << "O produto tem procedencia: Centro-Oeste";
		break;
	case 5:
	case 6: cout << "O produto tem procedencia: Nordeste";
		break;
	case 7:
	case 8:
	case 9: cout << "O produto tem prcedencia: Sudeste";
		break;
	}

}