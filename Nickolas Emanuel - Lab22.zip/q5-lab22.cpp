#include <iostream>
using namespace std;

int main()
{
	double num1, num2;
	int escolha;
	do
	{
		cout << "MINI-CALCULADORA" << endl;
		cout << "-----------------" << endl;
		cout << "1) +\n" << "2) -\n" << "3) *\n" << "4) /\n" << "5) Para sair da calculadora.\n";

		cout << "Qual opera��o deseja realizar?" << endl;
		cin >> escolha;

		cout << "Entre com os numeros com os quais voce deseja realizar a operacao: " << endl;
		cin >> num1 >> num2;

		switch (escolha)
		{
		case 1: cout << "A soma entre " << num1 << " e " << num2 << " e igual a: " << (num1 + num2) << endl;
			break;
		case 2:cout << "A subtracao entre " << num1 << " e " << num2 << " e igual a: " << (num1 - num2) << endl;
			break;
		case 3: cout << "A multiplicacao entre " << num1 << " e " << num2 << " e igual a: " << (num1 * num2) << endl;
			break;
		case 4: cout << "A divisao entre " << num1 << " e " << num2 << " e igual a: " << (num1 / num2) << endl;
		}
		system("pause");
		system("cls");
	} while (escolha != 5);
	
}