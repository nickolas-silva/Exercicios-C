#include <iostream>
using namespace std;

enum {a,b,c,s};
void menu(void);
void pedidof(float, float, float);

int main()
{
	const float alfacep = 1.25;
	const float beterrabap = 0.65;
	const float cenourap = 0.90;
	char escolha;
	float pedido = 0;
	float pedidoa = 0;
	float pedidob = 0;
	float pedidoc=0;
	int kga = 0;
	int kgb = 0;
	int kgc = 0;
	int kg=0;
	float entre, desc=0;

	do
	{
		menu();
		cin >> escolha;

		switch (escolha)
		{
		case 'a': cout << "Digite quantos quilos de alface voce deseja: ";
			cin >> kga;
			pedidoa = (alfacep * kga);
			break;

		case 'b': cout << "Digite quantos quilos de beterraba voce deseja: ";
			cin >> kgb;
			pedidob = (beterrabap * kgb);
			break;

		case 'c':	cout << "Digite quantos quilos de cenoura voce deseja: ";
			cin >> kgc;
			pedidoc = (cenourap * kgc);
			break;		
		}
		cout << endl;
	} while (escolha != 's');

	pedido = (pedidoa + pedidob + pedidoc);
	kg = (kga + kgb + kgc);

	if (pedido > 100)
		desc = (pedido * 0.95);

	if (kg < 5)
		entre = 3.5;
	if (kg >= 5 && kg < 20)
		entre = 10;
	if (kg == 20)
		entre= 8 ;
	if (kg > 20)
	{
		entre = 8;
		entre += ((kg - 20) * 0.10);
	}
	
	cout << endl;
	cout << "Produto		Preco/KG	Pedido (KG)		Total Parcial" << endl;
	cout << "-------		--------	-----------		-------------" << endl;
	cout << "Alface		R$ 1,25/Kg	" << kga << "Kg			R$ " << pedidoa << endl;
	cout << "Beterraba	R$ 0,65/Kg	" << kgb << "Kg			R$ " << pedidob << endl;
	cout << "Cenoura		R$ 0.90/Kg	" << kgc << "Kg			R$ " << pedidoc << endl;
	cout << endl;
	pedidof(pedido, desc, entre);


}
void menu(void)
{
	cout << "Supermercado ABC\n";
	cout << "----------------\n";
	cout << "a) Alface			R$ 1,25/Kg\n";
	cout << "b) Beterraba			R$ 0,65/Kg\n";
	cout << "c) Cenoura			R$ 0.90/Kg\n";
	cout << "Faca seu pedido usando as letras (a, b, c) e (s) para encerrar:" << endl;

}
void pedidof(float pedido, float desc, float entrega)
{
	cout << fixed; cout.precision(2);
	cout << "Total do pedido:				R$ " << pedido << endl;
	cout << "Descontos: 					R$ " << desc << endl;
	cout << "Custo da entrega:				R$ " << entrega << endl;
	cout << "------------------------------------------------------------" << endl;
	cout << "Total a pagar:					R$ " << ((pedido - desc) + entrega);
}