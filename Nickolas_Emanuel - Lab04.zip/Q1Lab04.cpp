#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	int p1, p2;
	cout << "Ponto P: \n";
	cin >> p1 >> p2;

	int q1, q2;
	cout << "Ponto Q: \n";
	cin >> q1 >> q2;

	int result, result1, result2;
	result1 = pow((q1 - p1), 2);
	result2 = pow((q2 - p2), 2);
	result = (result1 + result2);

	float dist;
	dist = sqrt(result);

	cout << "A distancia entre P e Q � " << dist;





}