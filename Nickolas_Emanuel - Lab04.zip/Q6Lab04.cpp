#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;
void inicializar();
void ligar(void);
void verificar(void);
void ativar(void);


int main()
{
	inicializar();
	
}

void ativar(void)
{
	cout << " - Ativando processos\n";
}
void verificar(void)
{
	cout << " - Verificando integridade\n";
}

void ligar(void)
{
	cout << " - Ligando dispositivos\n";
}

void inicializar(void)
{
	cout << "Inicializando Sistema:\n";
	ligar();

	verificar();

	ativar();

	cout << "Inicializa��o concluida.\n";
	srand(time(NULL));
	int num = rand();

	if (num > 16384)
		cout << "Sistema em funcionamento\n";
	else
		cout << "Falha na inicializa�ao\n";
	
	

	

}