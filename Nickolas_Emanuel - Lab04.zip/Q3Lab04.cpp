#include <iostream>
#include <cmath>
using namespace std;
void media(void);

int main()
{
	 media();

}

void media(void)
{
	float num1, num2;
	cout << "Digite um valor inteiro: \n";
	cin >> num1;
	cout << "Digite outro valor inteiro: \n";
	cin >> num2;

	float media;
	media = (( num1 + num2 ) / 2);
	cout << "A media dos numeros �: " << media;
}