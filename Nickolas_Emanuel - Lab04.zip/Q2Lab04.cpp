#include <iostream>
#include <cmath>
using namespace std;


int main()
{
	int ang;
	cout << "Digite um angulo: ";
	cin >> ang;

		double pi = 3.1415926535;
		double x;
		x = ((ang * pi) / 180);
		cout << "Seno:" <<(sin(x));
		
	}
	


