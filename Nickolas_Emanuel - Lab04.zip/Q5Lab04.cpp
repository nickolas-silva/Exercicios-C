#include <iostream>
#include <cmath>
using namespace std;
void absoluto(void);

int main()
{
	absoluto();
}

void absoluto(void)
{
	int num;

	cout << "Digite um n�mero inteiro:";
	cin >> num;
	num = pow(num, 2);
	num = sqrt(num);
	cout << "O valor absoluto �: " << num;

}