#include <iostream>
#include <cmath>
using namespace std;
void volumecilindro(void);

int main()
{
	cout << "Calculando o Volume do Cilindro\n" << "-------------------------------" << endl;

	volumecilindro();

	

	

	
}

void volumecilindro()
{
	int raio, altura;
	cout << "Entre com o raio da base: \n";
	cin >> raio;

	cout << "Entre com a altura: \n";
	cin >> altura;

	double volume;
	volume = (3.14159 * pow(raio, 2) * altura);
	

	cout << "O volume �: " << volume;
}