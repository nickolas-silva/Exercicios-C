#include <iostream>
using namespace std;

struct Pessoa
{
	char nome[20];
	int idade;
	char sexo[10];

};

int main()
{
	Pessoa usuario;
	do
	{
		cout << "Informe a idade da pessoa: ";
		cin >> usuario.idade;

		cout << "Informe o sexo da pessoa: ";
		cin >> usuario.sexo;

		cout << "Informe o nome da pessoa: ";
		cin >> usuario.nome;

	} while (strcmp(usuario.nome, "fim"));
}