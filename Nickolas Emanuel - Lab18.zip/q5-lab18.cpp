#include <iostream>
using namespace std;

int main()
{
	int idade;
	int m18 = 0;
	cout << "Digite as idades do grupo:" << endl;
	do 
	{

		cin >> idade;
		if (idade > 18)
			m18 += 1;
		else;

	}
	while (idade != 0);

	cout << "Nesse grupo " << m18 << " pessoas s�o maiores de 18 anos.";
}