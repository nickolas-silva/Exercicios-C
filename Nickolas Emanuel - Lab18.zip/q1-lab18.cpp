#include <iostream>
using namespace std;

int main() {
	int i = 0;
	while (++i < 4)
		cout << "Oi! ";
	do
		cout << "Tchau! ";
	while (i++ <= 8);
}
//Exibe "Oi!" tr�s vezes e "Tchau!" seis vezes.
//No la�o While o i come�a sendo igual a 1 e depois vai sendo incrementado para 2 e 3. 
//Ao chegar no 4 o la�o while se torna falso e o programa ja tendo exibido "Oi!" 3 vezes,segue com o valor de i igual a 4.
//No la�o Do While ele exibe "Tchau!" uma vez antes mesmo de verificar o valor de i.
//Depois o i vai sendo incrementado de 1 em 1 de 4 at� 8, onde "Tchau!" vai ser exbido mais 5 vezes totalizando 6.