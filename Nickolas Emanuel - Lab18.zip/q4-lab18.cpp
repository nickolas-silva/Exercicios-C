#include <iostream>
#include <cstring>
using namespace std;

int main() {
	cout << "Digite uma frase:";
	char frase[60];
	cin >> frase;
	
	
	int i, j;
	char frasei[60];
	
	
	j = 0;
	i = strlen(frase) - 1;
	cout << "A mesma frase so que ivertida invertida: ";
	//Teste
	while(i>=0)
	{
		
		if (frase[j] == frase[i])
		{
			j++;
		}
		else
			;
		cout << frase[i];
		i--;
	}
	cout << endl;
	if (j == strlen(frase))
		cout << "Essa frase e um palindromo.";
	else
		cout << "Essa frase nao e um palindromo.";
}