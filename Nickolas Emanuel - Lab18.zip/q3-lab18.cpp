#include <iostream>
using namespace std;

int main()
{
	cout << "Digite um texto: " << endl;

	char txt[50];
	cin.getline(txt, 50);

	int i = 0;
	while (txt[i] != '@')
	{
		cout << txt[i];
		i++;

	}

}