#include <iostream>
using namespace std;

int main()
{
	int i, soma=0;
	int somaw = 0;
	int somadw = 0;

	for (i = 1; i <= 100; i += 2)
	{
		soma += i;
	}
	cout << soma<< endl;

	i = 1;
	while (i <= 100)
	{
		somaw += i;
		i += 2;
	}
	cout << somaw << endl;

	i = 1;
	do
	{
		somadw += i;
		i += 2;
	} while (i <= 100);
	cout << somadw;
}
