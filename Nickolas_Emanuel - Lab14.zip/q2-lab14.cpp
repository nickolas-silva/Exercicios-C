#include <iostream>
using namespace std;

struct horario
{
	int hr, min;
};

void MostrarHorario(horario * ptr)
{
	cout.width(2); cout.fill('0');
	cout << (ptr->hr + 1);
	cout << " : ";
	cout.width(2); cout.fill('0');
	cout << ptr->min;
	

}

int main() {
	horario time;
	int pont;
	char pontos;
	
	
	cout << "Que horas sao? ";
	cin >> time.hr >> pontos >> time.min;

	cout << "Seu relogio esta atrasado, o horario correto e: ";
	MostrarHorario(&time);
}