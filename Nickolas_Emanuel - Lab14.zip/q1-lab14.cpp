#include <iostream>
using namespace std;

enum est {cheia, vazia};
enum ali {canja, sopa};
struct Tigela
{
	est estado;
	char alimento[15];

};
void Fome(Tigela * ptr);

int main()
{
	Tigela tgl;
	tgl.estado = cheia;

	cout << "Digite o tipo de alimento:";
	cin.getline(tgl.alimento, 15);

	cout << "A tigela antes da Janta:" << endl << "Estado:";
	if (tgl.estado == cheia)
	{
		cout << "CHEIA";
	}
	else
	{

	}
	
	cout << endl << "Alimento: " << tgl.alimento << endl;

	cout << endl;

	Fome(&tgl);
}
void Fome(Tigela * ptr)
{
	ptr->estado = vazia;

	cout << "A tigela depois da Janta: " << endl;
	cout << "Estado: ";
	if (ptr->estado == vazia)
	{
		cout << "VAZIA";
	}
	else
	{
		cout << "Continua cheia";
	}
	cout << endl << "Alimento: " << ptr->alimento;
}