#include <iostream>
using namespace std;

enum tp {JPG=1, PNG, BMP};
struct Imagem
{
	char nome[20];
	int larg, alt;
	tp tipo;

};
void Detalhes(Imagem* ptr, int);

int main()
{
	Imagem img1;
	char png[4] = { "PNG" };
	char jpg[4] = { "JPG" };
	char bmp[4] = { "BMP" };
	int type;

	cout << "Nome: ";
	cin.getline(img1.nome, 20);

	cout << "Largura e Altura: ";
	cin >> img1.larg;
	cin >> img1.alt;

	cout << "Qual o tipo da imagem? ";
	cin >> type;
	


	

	cout << endl;
	Detalhes(&img1, type);

}
void Detalhes(Imagem* ptr, int tip)
{
	cout << "A imagem \"" << ptr->nome << "\" com tamanho " << ptr->larg << "x" << ptr->alt << " tem formato ";
	if (tip == JPG)
	{
		cout << "JPG";
	}
	else
	{

	}
	if (tip == PNG)
	{
		cout << "PNG";
	}
	else
	{

	}
	if (tip == BMP)
	{
		cout << "BMP";
	}
	else
	{

	}


}