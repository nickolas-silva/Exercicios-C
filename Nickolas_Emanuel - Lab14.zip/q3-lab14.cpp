#include <iostream>
using namespace std;
int main()
{
	int valor = 10, * temp, soma = 0;
	temp = &valor;
	*temp = 20;
	temp = &soma;
	*temp = valor;
	cout << "valor: " << valor << "\nsoma: " << soma << endl;
}//Os valores das variaveis valor e soma s�o alterados atraves do uso do ponteiro temp.//Ao associar o endere�o de uma vari�vel em temp e depois mudar o valor do conteudo dentro desse endere�o os valores de valor e soma s�o alterados.