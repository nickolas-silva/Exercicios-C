#include <iostream>
using namespace std;
float aumento(float a);

int main()
{
	float salario;
	cout << "Salario atual: R$";
	cin >> salario;
	cout << "Salario ajustado para: R$" << aumento(salario) << endl;


}
float aumento(float a )
{
	float salarioa;
	salarioa = (a * 1.15);
	return salarioa;
}