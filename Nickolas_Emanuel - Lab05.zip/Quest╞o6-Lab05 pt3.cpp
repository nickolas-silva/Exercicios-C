#include <iostream>
#include <cmath>
using namespace std;
double vetor(double a, double b)
{
	float vet;
	vet = (sqrt(pow(a, 2) + pow(b, 2)));
	if (vet < 0)
		vet = (vet * -1);
	else
		vet = vet;
	return vet;


}
double om(double a, double b)
{
	double O, ang;
	O = atan(b / a);
	ang = ((O * 180) / 3.14159);
	return ang;

}