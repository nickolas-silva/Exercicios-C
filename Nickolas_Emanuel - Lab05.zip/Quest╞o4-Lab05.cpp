#include <iostream>
#include <cmath>
using namespace std;
float vetor(float, float);

int main()
{
	float x, y;
	cout << "Digite as coordenadas do vetor: " << endl;
	cout << "X:";
	cin >> x;
	cout << "Y:";
	cin >> y;
	cout << "O tamanho do vetor �: " << vetor(x, y);

}
float vetor(float a, float b)
{
	float vet;
	vet = (sqrt(pow(a, 2) + pow(b, 2)));
	if (vet < 0)
		vet = (vet * -1);
	else
		vet = vet;
	return vet;


}