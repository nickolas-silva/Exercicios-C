#include <iostream>
#include <cmath>
using namespace std;
double om(double, double);
double vetor(double, double);

