#include <iostream>
#include <cmath>
using namespace std;
double om(double, double);

int main()
{
	cout << "Digite as coordenadas do vetor:" << endl;
	double x, y;
	cout << "X:";
	cin >> x;
	cout << "Y:";
	cin >> y;
	cout << "O angulo do vetor �: " << om(x, y);

}
double om(double a, double b)
{
	double O, ang;
	O = atan (b / a);
	ang = ((O * 180) / 3.14159);
	return ang;

}