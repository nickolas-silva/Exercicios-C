#include <iostream>
#include <cmath>
using namespace std;
float imc(float, float);

int main()
{
	cout << "Indice de Massa Corporal (IMC)" << endl
		<< "------------------------" << endl;

	float altura, massa;
	cout << "Altura: ";
	cin >> altura;
	cout << "Massa: ";
	cin >> massa;
	cout << "IMC: " << imc(massa, altura);


}
float imc(float a, float b)
{
	float imc;
	
	imc = (a / (pow(b, 2)) );
	return imc;

}