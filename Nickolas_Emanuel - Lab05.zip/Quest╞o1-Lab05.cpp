#include <iostream>
using namespace std;

int main()
{
	int x;
	x = 1;

	int y = 1;
	//Exisite sim diferen�a entre essas duas formas
	//No caso do y o valor dele esta sendo atribuido diretamente e o x esta sendo atribuido fora.
	//Dependendo do c�digo n�o vai interferir no resultado.
	//Mas caso fosse preciso mudar o valor de y em outra linha n�o seria poss�vel. Enquanto o valor de x poderia ser alterado.
}