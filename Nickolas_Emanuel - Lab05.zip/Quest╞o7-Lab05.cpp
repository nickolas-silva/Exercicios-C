#include <iostream>
using namespace std;
double quadrado(double);
double cubo(double);

int main()
{
	double num;
	cout << "Digite um valor: ";
	cin >> num;
	cout << "Quadrado = " << quadrado(num) << endl;
	cout << "Cubo = " << cubo(num) << endl;
	cout << "Cubo do quadrado = " << cubo(quadrado(num)) << endl;




}
double quadrado(double a)
{
	double result;
	result = (a * a);
	return result;
}
double cubo(double a)
{
	double result;
	result = (a * a * a);
	return result;
}
