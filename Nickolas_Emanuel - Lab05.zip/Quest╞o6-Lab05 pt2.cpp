#include <iostream>
#include "Quest�o6-Lab05 pt1.h"

using namespace std;
int main()

{
	double x, y;
	cout << "Digite as coordenadas do vetor: \n";
	cout << "X:";
	cin >> x;
	cout << "Y:";
	cin >> y;
	cout << "Coordenadas polares do vetor: \n" << "( " << vetor(x, y) << ", " << om(x, y) << " )";

}
