#include <iostream>
using namespace std;

int main(int argc, char** argv)
{
	cout << "Programa: " << argv[1] << endl;

	system(argv[1]);
	return 0;
}