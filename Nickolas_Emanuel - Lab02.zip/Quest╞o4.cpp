#include <iostream>
using namespace std;

int main(int argc, char ** argv)
{
	cout << "Estou aprendendo " << argv[3] << "/" << argv[1] << "!" << endl;
	
	
	return 0;
}