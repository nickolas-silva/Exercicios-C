#include <iostream>
using namespace std;

int main() {
	cout << "Quantos valores deseja guardar? ";
	int tam;
	cin >> tam;

	int* vet = new int [tam];

	cout << "Quais os valores? ";
	int i;
	for (i=0; i < tam; i++)
	{
		cin >> vet[i];
		
	}
	cin.get();

	cout << "Os valores ";
	for (i = 0; i < (tam - 2); i++)
	{
		cout << vet[i] << ", ";
	}

	cout << (vet[tam - 2]) << " e " << (vet[tam - 1]) << " foram armazenados.";
	delete [] vet;
}	