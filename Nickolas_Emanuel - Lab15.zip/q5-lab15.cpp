#include <iostream>
using namespace std;

struct ASCII
{
	char ch;
	int val;
};
int* fun(int, char);

int main()
{
	ASCII tt;
	cout << "Digite um caractere: ";
	cin >> tt.ch;

	cout << "Digite um valor inteiro: ";
	cin >> tt.val;

	int * pnum = fun(tt.val, tt.ch);
	
	cout << pnum;

	delete pnum;

}
int* fun(int val, char ch)
{
	int* p = new int{ ch };
	
	*p = *p + val;
	return p;
}