#include <iostream>
using namespace std;

struct Local
{
	char nome[20];
	char pais[20];
	char continente[20];

};
int main()
{
	cout << "Quantos locais deseja visitar? ";
	int qnt;
	cin >> qnt;

	Local * vet = new Local[qnt];

	int i;
	for (i = 0; i < qnt; i++)
	{
		int l = i + 1;
		cout << "Insira os detalhes do " << l << "� Local: " << endl;
		cin.get();

		cout << "Digite o nome do Continente: ";
		cin.getline(vet[i].continente, 20);
		
		
		cout << "Digite o nome do Pais: ";
		cin.getline((vet[i].pais), 20);

		
		cout << "Digite o nome do Lugar: ";
		cin.getline(vet[i].nome, 20);
		
		cout << endl;
		
	}
	cout << "Esses foram os detalhes dos locias armazenados: " << endl;
	for (i = 0; i < qnt; i++)
	{
		int l = i + 1;
		cout << l << "� Local: " << endl;

		cout << "Continente: " << vet[i].continente << endl;
		cout << "Pais: " << vet[i].pais << endl;
		cout << "Local: " << vet[i].nome << endl;

	}
	delete[] vet;


}