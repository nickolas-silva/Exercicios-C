#include <iostream>
using namespace std;

int main()
{
	int* pi = new int;
	*pi = 100;

	cout << "Conteudo armazenado: " << *pi << endl;
	

	cout << "Digite um novo valor para esse bloco de memoria: ";
	cin >> *pi;

	
	delete pi;
}