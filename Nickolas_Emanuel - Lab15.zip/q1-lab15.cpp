#include <iostream>
using namespace std;

int main()
{
	float peso;
	peso = 30;
	cout << peso;
	delete peso;
	//O codigo acima esta errado, pois o delete so pode ser usando com ponteiros.
	//Ou seja n�o � possivel usar o delete com variaveis.
}