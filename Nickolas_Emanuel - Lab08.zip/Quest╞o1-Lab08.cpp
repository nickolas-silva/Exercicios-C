#include <iostream>
#include <cmath>
using namespace std;
void raizes(float, float, float);

int main()
{

	cout << "Calculadora de raizes de equa��o quadratica /'ax�+bx+c/'" << endl << "Insira os valores de a, b e c\n";
	int a, b, c;
	cin >> a >> b >> c;
	raizes(a, b, c);

}
void raizes(float a, float b, float c)
{
	float delta = (pow(b, 2) - 4 * a * c);
	float raizp = ((-b + sqrt(delta)) / (2 * a));
	float raizn = ((-b - sqrt(delta)) / (2 * a));
	if (delta < 0)
		cout << "N�o existem raizes reais para essa equa��o";
	else

		cout << "As raizes reais para essa equa��o s�o: " << raizp << " e " << raizn << endl;
}