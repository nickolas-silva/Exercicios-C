#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	float numero;
	numero = ((+1) * (pow(2, (200 - 127))) * (1 + 0.25 + 0.125 + 0.0078125 + 0.001953125));
	cout << "O n�mero em decimal: " << numero;
}