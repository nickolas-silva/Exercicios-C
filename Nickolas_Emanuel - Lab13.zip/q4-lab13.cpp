#include <iostream>
using namespace std;
enum mes { DOM, SEG, TER, QUA, QUI, SEX, SAB };
int main()
{
	char meses[12][10] =
	{
   "Domingo", "Segunda", "Terca", "Quarta", "Quinta", "Sexta",
   "Sabado"
	};
	for (mes ind = DOM; ind <= SAB; ind = mes(ind + 1))
		cout << meses[ind] << endl;
	
}