#include <iostream>
using namespace std;

enum trave { LEsq, LDir, CantoEsq, CantoDir, Centro };
union jogador
{
	char nome[25];
	int numero;
};
struct gol
{
	jogador jog; // identifica��o do jogador
	float x, y, z; // posi��o da bola nas coordenadas
	trave local; // onde a bola entrou
	float velo; // velocidade da bola
	float acel; // acelera��o da bola
};
gol estatistica[10]; // estat�sticas para at� 10 gols

//estatistica = tipo gol[10]
//estatistica[4] = inv�lido
//estatistica[1].jog = inv�lido
//estatistica->jog.numero = tipo int
//(estatistica + 9)->local = tipo trave
//estatistica[2].velo = tipo float
//(estatistica + 1)->jog.nome[0] = tipo char
//estatisitca[6].acel = tipo float
