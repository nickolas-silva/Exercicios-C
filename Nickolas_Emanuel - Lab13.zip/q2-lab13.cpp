#include <iostream>
using namespace std;

union jogador
{
	char nome[25]; // nome do jogador
	int numero; // numero da camisa do jogador
};
struct gol
{
	jogador jog; // identifica��o do jogador
	int hora, min; // hora e minuto em que o gol foi marcado
};
int main()
{
	gol gols[3];
	

	char pontos;
	cout << "Digite os dados dos 3 ultimos gols: " << endl;

	cout << "Gol1: ";
	cin >> gols[0].jog.nome >> gols[0].hora >> pontos >> gols[0].min;

	cout << "Gol2: ";
	cin >> gols[1].jog.nome >> gols[1].hora >> pontos >> gols[1].min;

	cout << "Gol3: ";
	cin >> gols[2].jog.nome >> gols[2].hora >> pontos >> gols[2].min;

}