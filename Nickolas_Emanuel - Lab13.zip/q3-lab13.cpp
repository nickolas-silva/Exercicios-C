#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <string>
using namespace std;

struct dma
{
	int dia, mes, ano;
};
struct horario
{
	int hora, min;
}; 
struct evento
{
	char desc[18];
	dma data;
	horario hr;
};
int main()
{
	evento ev[2];

	 cout << "Entre com dois eventos: " << endl;
	 cout << "#1" << endl;

	 cout << "Data: ";
	 cin >> ev[0].data.dia >> ev[0].data.mes >> ev[0].data.ano;

	 cout << "Hora: ";
	 cin >> ev[0].hr.hora >> ev[0].hr.min;
	 cin.get();
 
	 cout << "Descricao: ";
	 cin.getline(ev[0].desc, 18);
	
	 cout << endl;

	 cout << "#2" << endl;

	 cout << "Data: ";
	 cin >> ev[1].data.dia >> ev[1].data.mes >> ev[1].data.ano;
	

	 cout << "Hora: ";
	 cin >> ev[1].hr.hora >> ev[1].hr.min;
	 cin.get();


	
	 cout << "Descricao: ";
	 cin.getline(ev[1].desc, 18);
	
	

	 cout << "--------------------" << endl;

	 cout << "Eventos Cadastrados" << endl;
	 cout << ev[0].data.dia << "/" << ev[0].data.mes << "/" << ev[0].data.ano << " ";
	 cout.width(2); cout.fill('0');
	 cout << ev[0].hr.hora;
	 cout << ":";
	 cout.width(2); cout.fill('0');
	 cout << ev[0].hr.min;
	 cout << " ";
	 cout << ev[0].desc;

	 cout << endl;

	 cout << ev[1].data.dia << "/" << ev[1].data.mes << "/" << ev[1].data.ano << " ";
	 cout.width(2); cout.fill('0');
	 cout << ev[1].hr.hora;
	 cout << ":";
	 cout.width(2); cout.fill('0');
	 cout << ev[1].hr.min;
	 cout << " ";
	 cout << ev[1].desc;

	 cout << endl;
}