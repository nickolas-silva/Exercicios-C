#include <iostream>
using namespace std;

int main()
{
	char nome[50];
	char data[15];
	char esteve[30] = " esteve aqui em ";

	cout << "Nome: ";
	cin.getline(nome, 15);
	

	cout << "Data: ";
	cin.getline(data, 15);

	
	cout << nome << esteve << data;

}