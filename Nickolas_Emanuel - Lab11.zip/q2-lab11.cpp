#include <iostream>
#include <string>
using namespace std;

int main()
{
	int num1;
	char num2[5];

	cout << "Entre com dois numeros: ";
	cin >> num1 >> num2;
	
	int mult = (num1 * (atoi(num2)));

	cout << "A multiplica��o entre eles �: " << mult;


}