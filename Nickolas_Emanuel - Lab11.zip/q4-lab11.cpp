#include <iostream>
#include <string>
using namespace std;

int main()
{
	string data1;
	string data2;
	string data3;
	string natal = "Natal";

	cout << "Quais suas datas comemorativas preferidas? \n";
	getline(cin, data1);
	getline(cin, data2);
	getline(cin, data3);

	cout << data1 << ", " << data2 << " e " << data3 << " sao belas festas." << endl;

	if (data1 == natal)
		cout << "O Natal tambem � uma das minhas preferidas! ";
	else
	{

	}

		if (data2 == natal)
			cout << "O Natal tambem � uma das minhas preferidas! ";
		else
		{

		}
			if (data3 == natal)
				cout << "O Natal tambem � uma das minhas preferidas! ";
			else
			{

			}


}