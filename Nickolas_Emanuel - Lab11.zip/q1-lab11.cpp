#include <iostream>
#include <string>
using namespace std;

int main()
{
	string senha = "teste";
	char senhau[10];

	cout << "Digite a senha: ";
	cin >> senhau;
	cin.get();
	cout << endl;
	if (senhau == senha)
	{
		cout << "Senha correta \n\a";
	}
	else
	{
		cout << "Senha incorreta \n\a";
	}

}