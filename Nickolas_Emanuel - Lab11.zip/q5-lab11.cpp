#include <iostream>
using namespace std;

int main()
{
	char nome[15];
	char sobrenome[15];

	cout << "Digite seu nome e sobrenome ";
	cin >> nome >> sobrenome;
	cout << "Bom dia senhor, " << sobrenome << ". " << "Ou devo te chamar de " << nome << "? ";

}
