#include <iostream>
#include <fstream>
using namespace std;

void unidade(ifstream &, int);

int main() 
{
	ifstream fin;
	fin.open("q1.txt");
	unidade(fin, 1);
	unidade(fin, 2);
	unidade(fin, 3);
	fin.close();
}

void unidade(ifstream& file, int uni)
{
	
	int lab;
	int ex_re, ex_fix, ex_ap;
	int t_re = 0;
	int t_fix = 0;
	int t_ap = 0;

	double total = 0;

	int cont = 0;
	while (cont != 10)
	{
		
		file >> lab >> ex_re >> ex_fix >> ex_ap;
		t_re += ex_re;
		t_fix += ex_fix;
		t_ap += ex_ap;
		
		cont++;
		
	}
	cout << "-----------\n";
	cout << "-----------\n";
	cout << uni << "a Unidade" << endl;

	cout << "Revisao: " << t_re << endl;
	cout << "Fixacao: " << t_fix << endl;
	cout << "Aprendi: " << t_ap << endl;
	cout << "-----------\n";
	cout << "Total: " << (t_re + t_fix+t_ap) << endl;
}