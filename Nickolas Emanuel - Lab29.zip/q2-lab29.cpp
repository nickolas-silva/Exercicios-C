#include <iostream>

using namespace std;

void print(int num);
void print(double num);
void print(const char * str);

int main()
{
	
	cout << "Inteiro: ";
	print(45);
	cout << "\nPonto-flutuante: ";
	print(3.5);
	cout << "\nString: ";
	print("Oi Mundo");
	cout << "\n";
}
void print(double num)
{
	cout << num;
}
void print(int num)
{
	cout << num;
}
void print(const char * str)
{
	cout << str;
}