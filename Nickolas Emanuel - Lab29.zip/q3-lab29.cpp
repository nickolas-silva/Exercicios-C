#include <iostream>
#include <string>
using namespace std;
template <typename T> void print(T &a,T & b)
{
	T temp = a + b;
	cout << a << " + " << b << " = " << temp << endl;
}
int main()
{
	string strA = "Pro";
	string strB = "gramando";
	int x = 1;
	int y = 2;
	print(x, y);

	float e = 2.6;
	float d = 3.7;
	print(e, d);

	int a = 'A';
	int b = 'B';
	print(a,b);
	print(strA, strB);
}