#include <iostream>
#include <fstream>


using namespace std;

struct dados
{
	char nome[20];
	char sobrenome[20];
	char turno;
	int serie;

};
int main()
{

	ifstream fin;
	fin.open("q3.txt");

	dados aluno[12];

	for (int i = 0; i < 12; i++)
	{
		fin >> aluno[i].nome;
		
		fin >> aluno[i].sobrenome >> aluno[i].turno >> aluno[i].serie;
	}
	
	cout << "Matutino 6a Serie\n";
	cout << "----------------\n";
	for (int i = 0; i < 12; i++)
	{
		if (aluno[i].turno == 'M' && aluno[i].serie == 6)
		{
			cout << aluno[i].nome << " " << aluno[i].sobrenome << " " << aluno[i].turno << aluno[i].serie << endl;
		}
	}
	cout << endl;
	cout << "Matutino 7a Serie\n";
	cout << "----------------\n";
	for (int i = 0; i < 12; i++)
	{
		if (aluno[i].turno == 'M' && aluno[i].serie == 7)
		{
			cout << aluno[i].nome << " " << aluno[i].sobrenome << " " << aluno[i].turno << aluno[i].serie << endl;
		}
	}
	cout << endl;
	cout << "Matutino 8a Serie\n";
	cout << "----------------\n";
	for (int i = 0; i < 12; i++)
	{
		if (aluno[i].turno == 'M' && aluno[i].serie == 8)
		{
			cout << aluno[i].nome << " " << aluno[i].sobrenome << " " << aluno[i].turno << aluno[i].serie << endl;
		}
	}
	cout << endl;
	cout << "Vespertino 6a Serie\n";
	cout << "----------------\n";
	for (int i = 0; i < 12; i++)
	{
		if (aluno[i].turno == 'T' && aluno[i].serie == 6)
		{
			cout << aluno[i].nome << " " << aluno[i].sobrenome << " " << aluno[i].turno << aluno[i].serie << endl;
		}
	}
	cout << endl;
	cout << "Vespertino 7a Serie\n";
	cout << "----------------\n";
	for (int i = 0; i < 12; i++)
	{
		if (aluno[i].turno == 'T' && aluno[i].serie == 7)
		{
			cout << aluno[i].nome << " " << aluno[i].sobrenome << " " << aluno[i].turno << aluno[i].serie << endl;
		}
	}
	cout << endl;
	cout << "Vespertino 8a Serie\n";
	cout << "----------------\n";
	for (int i = 0; i < 12; i++)
	{
		if (aluno[i].turno == 'T' && aluno[i].serie == 8)
		{
			cout << aluno[i].nome << " " << aluno[i].sobrenome << " " << aluno[i].turno << aluno[i].serie << endl;
		}
	}
}