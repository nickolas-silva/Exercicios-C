#include <iostream>
#include <fstream>
using namespace std;
int func(char[]);

int main()
{
	ofstream fout;
	fout.open("palindromos.txt");
	char palavra[20];
	int conti = 0;

	cin >> palavra;
	fout << "Arquivo: palindromos.txt\n";

	while (conti != 4)
	{
		if (func(palavra) == strlen(palavra))
		{
			fout << palavra << endl;
			conti++;
		}
		cin >> palavra;
	}
	fout << "Foram encontrados " << conti << " palindromos neste arquivo.";

	fout.close();
}
int func(char pal[])
{
	int cont = 0;
	int i = 0;
	int j = strlen(pal) - 1;

	while (j >= 0)
	{
		if (pal[i] == pal[j])
			i++;
		j--;
	}

	if (i > 1)
	{
		return i;
	}
	else
		return 0;
	

}