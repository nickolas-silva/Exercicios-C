#include <iostream>
#include <fstream>
using namespace std;

int main()
{
	ifstream fin;
	ofstream fout;
	fin.open("teste.cpp");
	fout.open("teste_m.cpp");

	char iostream[20];
	char usingn[30];
	char intmain[12];
	char palavra[30];

	fin.getline(iostream, 20);
	fin.getline(usingn, 30);
	fin.ignore();

	fin.getline(intmain, 12);

	fout << "//teste_m.cpp" << endl;
	fout << "#define print cout" << endl;
	fout << iostream << endl;
	fout << usingn << endl << endl;
	fout << intmain;

	while (fin.good())
	{
		fin >> palavra;
		if (!strcmp(palavra, "cout"))
			fout << "print";
		else
		fout << palavra << " ";


	}
	fin.close();
	fout.close();


	
}