#include <iostream>
using namespace std;

int func(char*);

int main()
{
	char frase[50];
	cout << "Entre com uma frase:\n";
	cin.getline(frase, 50);
	
	cout << "Existem " << func(frase) << " palavras nesta frase!";

}
int func(char *frase)
{
	char ch[20];
	int cont = 0;
	
	for (int i = 0; frase[i]; i++)
	{
		if (frase[i] == ' ' || frase[i]== '.' || frase[i] == '!')
			cont++;

	}
	return cont;
}
