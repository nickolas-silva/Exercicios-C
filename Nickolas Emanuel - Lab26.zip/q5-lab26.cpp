#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
using namespace std;

struct Charset
{
	char* str;
	int tam = 20;
};
int main()
{
	Charset x;
	char* ptr = new char[x.tam];
	char aux[20] = "drogas";
	strcpy(ptr, aux);
	x.str = ptr;
	
	cout << x.str << " " << strlen(x.str);
}
