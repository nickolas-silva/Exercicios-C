#include <iostream>
#include <fstream>
using namespace std;
struct Produto
{
	float pn;
	float pa;
	int qnt;

};

bool check(Produto, int);
float func(Produto[], int []);
int main()
{
	ifstream fin;
	fin.open("Produtos.txt");
	int tamvet;
	fin >> tamvet;

	Produto* vet = new Produto[tamvet];

	for (int i = 0; i < tamvet; i++)
	{
		char indi[3];
		fin >> indi >> vet[i].pn >> indi >> vet[i].pa >> indi >> vet[i].qnt;
	}

	fin.close();
	fin.open("Pedido.txt");
	int tam;
	fin >> tam;

	int* quant = new int[tam];
	for (int i = 0; i < tam; i++)
	{
		fin >> quant[i];
		
	}
	fin.close();

	cout << "O total do pedido foi de: " << func(vet, quant);
	delete[] vet;
	delete[] quant;
}
bool check(Produto x, int qnt)
{
	
	if (qnt >= x.qnt)
	{
		return true;
	}
	else {
		return false;
	}
}
float func(Produto vet[], int qnt[])
{
	float soma = 0;

	for (int i = 0; i < 6; i++)
	{
		if (check(vet[i], qnt[i]))
		{
			soma += (vet[i].pa * qnt[i]);
		}
		else
		{
			soma += (vet[i].pn * qnt[i]);
		}
	}





	return soma;
}