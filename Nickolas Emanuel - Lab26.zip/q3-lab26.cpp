#include <iostream>
using namespace std;

void first(char*);
void last(char*);
int main()
{
	cout << "Entre com os nomes para cadastrar ('.' para encerrar): \n";
	char nome[30];
	do
	{
		cin.getline(nome, 30);
		first(nome);
		cout << ", ";

		 last(nome);


	} while (nome[0] != '.');
}
void first(char* nome)
{
	int i = 0;
	while (nome[i] != ' ')
	{
		cout << nome[i];
		i++;
	}
	
}
void last(char* nome)
{
	int i = strlen(nome)-1;
	char* inv = new char[30];
	int cont = 0;
	
	for (int j = 0; j<=i ; j++)
	{
		inv[j] = nome[i - j];
		if (inv[j] == ' ')
			cont = j;
	}
	inv[cont] = '\0';
	int h = cont - 1;
	while (inv[h])
	{
		cout << inv[h];
		h--;
	}
		

		

}
char* InverteString(const char* str)
{
	char* invertida = new char[40];
	const int Tam = strlen(str);

	for (int i = 0; i < Tam; i++)
		invertida[i] = str[Tam - 1 - i];

	invertida[Tam] = '\0';

	return invertida;
}
