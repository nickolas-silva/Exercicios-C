#include <iostream>
using namespace std;
void format(char*);
int main()
{
	char nome[40];
	do
	{
		cin >> nome;
		format(nome);
		cout << " ";
	} while (strcmp(nome, "fim"));
}
void format(char* name)
{
	if (strlen(name) > 2)
	{
		cout << char(toupper(name[0]));
		for (int i = 1; name[i]; i++)
			cout << char(tolower(name[i]));
	}
	else
	{
		for (int i = 0; name[i]; i++)
			cout << char(tolower(name[i]));
	}
}