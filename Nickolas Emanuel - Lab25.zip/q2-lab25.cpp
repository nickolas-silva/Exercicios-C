#include <iostream>
#include <fstream>
using namespace std;

int menor(int[]);
int maior(int[]);
int psmenor(int[]);
int psmaior(int[]);

int main()
{
	int vet[100];
	char arquivo[20];
	ifstream fin;
	ofstream fout;
	cout << "Arquivo: ";
	cin.getline(arquivo, 20);

	fout.open(arquivo);
	for (int i = 1; i <= 100; i++)
		fout << i << endl;
	fout.close();

	fin.open(arquivo);
	for (int i = 0; i < 100; i++)
		fin >> vet[i];
	fin.close();

	cout << "A posicao " << psmenor(vet) << " contem o menor numero (" << menor(vet) << ")" << endl;

	cout << "A posicao " << psmaior(vet) << " contem o maior numero (" << maior(vet) << ")" << endl;


}
int menor(int vet[])
{
	int menor = 100;
	for (int j = 0; j < 100; j++)
	{
		if (menor > vet[j])
		{
			menor = vet[j];
		}
	}
	return menor;
		
}
int maior(int vet[])
{
	int maior = 0;
	for (int j = 0; j < 100; j++)
	{
		if (maior < vet[j])
		{
			maior = vet[j];
		}
	}
	return maior;

}
int psmenor(int vet[])
{
	int posi;
	int menor = 2;
	for (int j = 0; j < 100; j++)
	{
		if (menor > vet[j])
		{
			posi = j;
		}
	}
	return posi;
}
int psmaior(int vet[])
{
	int posi2;
	int maior = 0;
	for (int j = 0; j < 100; j++)
	{
		if (maior < vet[j])
		{
			posi2 = j;
		}
	}
	return posi2;
}
