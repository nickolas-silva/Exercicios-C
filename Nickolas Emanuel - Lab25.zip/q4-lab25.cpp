#include <iostream>
using namespace std;

int* func(int[], int[], int);

int main()
{
	const int tam = 4;
	int veta[tam] = {1,4,5,7};
	int vetb[tam] = {3,2,8,9};

	int* ptr = func(veta, vetb, tam);
	cout << "Vet A: " << veta[0] << " " << veta[1] << " " << veta[2] << " " << veta[3] << endl;
	cout << "Vet B: " << vetb[0] << " " << vetb[1] << " " << vetb[2] << " " << vetb[3] << endl;
	cout << "Uniao: " << ptr[0] << " " << ptr[1] << " " << ptr[2] << " " << ptr[3] << " "
		<< ptr[4] << " " << ptr[5] << " " << ptr[6] << " " << ptr[7];

}
int* func(int veta[], int vetb[], int tam)
{
	int tamt = tam + tam;
	int aux = 0;
	int* vett = new int[tamt];
	for (int i = 0; i < tam; i++)
		vett[i] = veta[i];
	for (int j = tam; j < tamt; j++)
	{
	
		vett[j] = vetb[aux];
		aux++;
	}

	return vett;
}