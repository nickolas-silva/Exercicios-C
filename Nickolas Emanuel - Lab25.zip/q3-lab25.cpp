#include <iostream>
using namespace std;

int main()
{
	int vet[10];
	int aux[10];
	cout << "Digite 10 valores: ";
	for (int i = 0; i < 10; i++)
		cin >> vet[i];
	for (int j = 0; j < 10; j++)
	{
		int cont = 0;
		for (int i = 0; i < 10; i++)
		{
			if (vet[j] < vet[i])
				cont++;

		}
		if (cont == 9)
		{
			aux[0] = vet[j];

		}
		if (cont == 8)
			aux[1] = vet[j];
		if (cont == 7)
			aux[2] = vet[j];
		if (cont == 6)
			aux[3] = vet[j];
		if (cont == 5)
			aux[4] = vet[j];
		if (cont == 4)
			aux[5] = vet[j];
		if (cont == 3)
			aux[6] = vet[j];
		if (cont == 2)
			aux[7] = vet[j];
		if (cont == 1)
			aux[8] = vet[j];
		if (cont == 0)
			aux[9] = vet[j];
	}





	cout << "Os valores ordenados: " << endl;
	for (int i = 0; i < 10; i++)
	{
		cout << aux[i] << " ";
	}
	
}