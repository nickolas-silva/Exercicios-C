#include <iostream>
using namespace std;
int func( int *, int, int *);

int main()
{
	int vet[11] = { 1,1,1,1,1,1,0,0,0,0,0 };
	int val;
	cout << "digite qual valor deseja descobrir a frequ�ncia: ";
	cin >> val;
	cout << "O " << val << " aparece " << func(vet, val, vet + 11) << " vezes";

}
int func(int * inicio,int val, int* fim)
{
	int* valor = &val;
	int cont=0;
	for (int * atual = inicio; atual != fim; atual++)
		if (*atual == *valor)
			cont++;
	return cont;
}