#include "crypto.h"

using namespace std;

long long codificar(int a)
{
	long long x;
	x = a;

	//Sorteio das posi��es que ir�o ser modificadas
	srand(time(NULL));
	
	unsigned int s1, s2, s3, s4, s5, s6;
	unsigned int st;
	s1 = rand() % 31;
	s2 = rand() % 31;
	s3 = rand() % 31;
	s4 = rand() % 31;
	s5 = rand() % 31;
	s6 = rand() % 31;

	//ZONA DE TESTES COM VALORES FIXOS (DESCONSIDERAR)
	int nt, n1, n2, n3, n4, n5, n6;
	n1 = 9;
	n2 = 3;
	n3 = 30;
	n4 = 4;
	n5 = 1;
	n6 = 12;

	//Chamada da fun��o para alterar os bits selecionados e alocar o resultado em 32 bits (bloco1)
	x = (testarbit(x, s1) );
	x = (testarbit(x, s2) );
	x = (testarbit(x, s3) );
	x = (testarbit(x, s4) );
	x = (testarbit(x, s5) );
	x = (testarbit(x, s6) );
	x = x << 32;

	//Alocando as posi��es em 32 bits (bloco2)
	s1 = s1 << 27;
	s2 = s2 << 22;
	s3 = s3 << 17;
	s4 = s4 << 12;
	s5 = s5 << 7;
	s6 = s6 << 2;
	st = (s1 + s2 + s3 + s4 + s5 + s6);

	//ZONA DE TESTES COM VALORES FIXOS (DESCONSIDERAR)
	n1 = n1 << 27;
	n2 = n2 << 22;
	n3 = n3 << 17;
	n4 = n4 << 12;
	n5 = n5 << 7;
	n6 = n6 << 2;
	nt = (n1 + n2 + n3 + n4 + n5 + n6);
	

	//Retornando um valor de 64 bits formado pelos 2 blocos
	return (x + st); 

}
unsigned int testarbit(unsigned int valor, unsigned int posicao)
{
	unsigned int bit = posicao;
	unsigned int mascara = 1 << bit;

	unsigned estado = valor;
	if (estado & mascara)
		return (desligarbit(estado, bit));
		
	else
		return (ligarbit(estado, bit));
}
unsigned int ligarbit(unsigned int valor, unsigned int posicao)
{
	unsigned int bit = posicao;
	unsigned int  mascara = 1 << bit;
	unsigned int estado = valor;
	estado = (estado | mascara);
	return long long (estado);
}
unsigned int desligarbit(unsigned int valor, unsigned int posicao)
{
	unsigned int bit = posicao;
	unsigned int mascara = ~(1 << bit);
	unsigned int estado = valor;
	estado = (estado & mascara);
	return long long (estado);
}
unsigned int decodificar(long long cripto)
{
	//Separando o bloco1 do valor de 64 bits
	long long bloco1 = cripto;
	bloco1 = bloco1 >> 32;

	//Separando o bloco2 do valor de 64 bits
	long long bloco2 = cripto << 32;
	bloco2 = bloco2 >> 32;

	//Separando as posi��es que foram sorteadas do bloco2
	unsigned int n1, n2, n3, n4, n5, n6;

	n1 = bloco2;
	n1 = n1 >> 27;

	n2 = bloco2;
	n2 = n2 << 5;
	n2 = n2 >> 27;

	n3 = bloco2;
	n3 = n3 << 10;
	n3 = n3 >> 27;

	n4 = bloco2;
	n4 = n4 << 15;
	n4 = n4 >> 27;

	n5 = bloco2;
	n5 = n5 << 20;
	n5 = n5 >> 27;

	n6 = bloco2;
	n6 = n6 << 25;
	n6 = n6 >> 27;

	//Transformando os valores do bloco1 no que eram antes 
	long long descript;
	descript = bloco1;
	descript = (testarbit(descript, n1));
	descript = (testarbit(descript, n2));
	descript = (testarbit(descript, n3));
	descript = (testarbit(descript, n4));
	descript = (testarbit(descript, n5));
	descript = (testarbit(descript, n6));
	
	
	
	return descript;
	
}
//Fun��es para separar um n�mero em 2 blocos de 32 bits

//Bloco 1
unsigned int bloco1(long long cripto)
{
	long long bloco;
	bloco = cripto;
	bloco = bloco >> 32;
	return bloco;
}
//Bloco 2
unsigned int bloco2(long long cripto)
{
	long long bloco = cripto << 32;
	bloco = bloco >> 32;
	return bloco;

}
//Fun��o para pegar o primeiro numero do bloco2
unsigned int n1(unsigned int bloco)
{
	unsigned int primeiro = bloco;
	primeiro = primeiro >> 27;
	return primeiro;
}
//Fun��o para pegar o segundo numero do bloco2
unsigned int n2(unsigned int bloco)
{
	unsigned int segundo = bloco;
	segundo = segundo << 5;
	segundo = segundo >> 27;
	return segundo;
}
//Fun��o para pegar o terceiro numero do bloco2
unsigned int n3(unsigned int bloco)
{
	unsigned int terceiro = bloco;
	terceiro = terceiro << 10;
	terceiro = terceiro >> 27;
	return terceiro;
}
//Fun��o para pegar o quarto numero do bloco2
unsigned int n4(unsigned int bloco)
{
	unsigned int quarto = bloco;
	quarto = quarto << 15;
	quarto = quarto >> 27;
	return quarto;
}
//Fun��o para pegar o quinto numero do bloco2
unsigned int n5(unsigned int bloco)
{
	unsigned int quinto = bloco;
	quinto = quinto << 20;
	quinto = quinto >> 27;
	return quinto;
}
//Fun��o para pegar o sexto numero do bloco2
unsigned int n6(unsigned int bloco)
{
	unsigned int sexto = bloco;
	sexto = sexto << 25;
	sexto = sexto >> 27;
	return sexto;
}