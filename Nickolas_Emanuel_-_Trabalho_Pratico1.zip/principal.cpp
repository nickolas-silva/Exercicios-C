#include <iostream>
#include "simd.h"
#include "crypto.h"
using namespace std;

//In�cio da Fun��o Principal
int main()
{
	//Entrada dos valores
	//Bloco 1
	char pontos;
	int num1, num2, num3, num4;
	cin >> pontos;
	cin >> num1;
	cin >> pontos;
	cin >> num2;
	cin >> pontos;
	cin >> num3;
	cin >> pontos;
	cin >> num4;
	cin >> pontos;
	//Bloco 2
	int num5, num6, num7, num8;
	cin >> pontos;
	cin >> num5;
	cin >> pontos;
	cin >> num6;
	cin >> pontos;
	cin >> num7;
	cin >> pontos;
	cin >> num8;
	cin >> pontos;
	cout << endl;


	//Sa�da dos valores juntos em um bloco de 32 dois bits
	//Bloco 1
	cout << "Operandos em 32 bits = " << armazena(num1, num2, num3, num4) << endl;
	//Bloco 2
	cout << "Operandos em 32 bits = " << armazena(num5, num6, num7, num8) << endl;
	cout << endl;
	
	//Soma entre os n�meros em um bloco de 32 bits
	cout << "Soma em 32 bits: " << armazena(soma(primeiro(armazena(num1, num2, num3, num4)), primeiro(armazena(num5, num6, num7, num8))), soma(segundo(armazena(num1, num2, num3, num4)), segundo(armazena(num5, num6, num7, num8))), soma(terceiro(armazena(num1, num2, num3, num4)), terceiro(armazena(num5, num6, num7, num8))), soma(quarto(armazena(num1, num2, num3, num4)), quarto(armazena(num5, num6, num7, num8)))) << endl;
	//Multiplica��o entre os n�meros em um bloco de 32 bits
	cout << "Mult em 32 bits: " << armazena(multi(primeiro(armazena(num1, num2, num3, num4)), primeiro(armazena(num5, num6, num7, num8))), multi(segundo(armazena(num1, num2, num3, num4)), segundo(armazena(num5, num6, num7, num8))), multi(terceiro(armazena(num1, num2, num3, num4)), terceiro(armazena(num5, num6, num7, num8))), multi(quarto(armazena(num1, num2, num3, num4)), quarto(armazena(num5, num6, num7, num8)))) << endl;
	cout << endl;

	
	
	//Saida da soma entre os blocos inidividualmente, com 3 casas decimais;
	cout << "[";

	//Primeiro + Primeiro
	cout.width(3); cout.fill('0');
	cout << soma(primeiro(armazena(num1, num2, num3, num4)), primeiro(armazena(num5, num6, num7, num8))) << ",";
	//Segundo + Segundo
	cout.width(3); cout.fill('0');
	cout << soma(segundo(armazena(num1, num2, num3, num4)), segundo(armazena(num5, num6, num7, num8))) << ",";
	//Terceiro + Terceiro
	cout.width(3); cout.fill('0');
	cout << soma(terceiro(armazena(num1, num2, num3, num4)), terceiro(armazena(num5, num6, num7, num8))) << ",";
	//Quarto + Quarto
	cout.width(3); cout.fill('0'); 
	cout << soma(quarto(armazena(num1, num2, num3, num4)), quarto(armazena(num5, num6, num7, num8)));
	cout << "] = Somas" << endl;



	//Saida da multiplica��o entre os blocos inidividualmente, com 3 casas decimais
	cout << "[";

	//Primeiro * Primeiro
	cout.width(3); cout.fill('0');
	cout << multi(primeiro(armazena(num1, num2, num3, num4)), primeiro(armazena(num5, num6, num7, num8))) << ",";
	//Segundo * Segundo
	cout.width(3); cout.fill('0');
	cout << multi(segundo(armazena(num1, num2, num3, num4)), segundo(armazena(num5, num6, num7, num8))) << ",";
	//Terceiro * Terceiro
	cout.width(3); cout.fill('0'); 
	cout << multi(terceiro(armazena(num1, num2, num3, num4)), terceiro(armazena(num5, num6, num7, num8))) << ",";
	//Quarto * Quarto
	cout.width(3); cout.fill('0');
	cout << multi(quarto(armazena(num1, num2, num3, num4)), quarto(armazena(num5, num6, num7, num8)));
	cout << "] = Multiplicacoes" << endl;
	cout << endl;


	//Valor da soma em 64 bits com posi��es aleat�rias alteradas
	cout << "Soma cripto 64 bits = " << codificar(armazena(soma(primeiro(armazena(num1, num2, num3, num4)), primeiro(armazena(num5, num6, num7, num8))), soma(segundo(armazena(num1, num2, num3, num4)), segundo(armazena(num5, num6, num7, num8))), soma(terceiro(armazena(num1, num2, num3, num4)), terceiro(armazena(num5, num6, num7, num8))), soma(quarto(armazena(num1, num2, num3, num4)), quarto(armazena(num5, num6, num7, num8))))) << endl;
	cout << "Mult cripto 64 bits = " << codificar(armazena(multi(primeiro(armazena(num1, num2, num3, num4)), primeiro(armazena(num5, num6, num7, num8))), multi(segundo(armazena(num1, num2, num3, num4)), segundo(armazena(num5, num6, num7, num8))), multi(terceiro(armazena(num1, num2, num3, num4)), terceiro(armazena(num5, num6, num7, num8))), multi(quarto(armazena(num1, num2, num3, num4)), quarto(armazena(num5, num6, num7, num8))))) << endl;
	cout << endl;

	//Valor do bloco com os Bits mais altos e o n�mero das posi��es alteradas
	cout << "Valor codificado = " << bloco1(codificar(armazena(soma(primeiro(armazena(num1, num2, num3, num4)), primeiro(armazena(num5, num6, num7, num8))), soma(segundo(armazena(num1, num2, num3, num4)), segundo(armazena(num5, num6, num7, num8))), soma(terceiro(armazena(num1, num2, num3, num4)), terceiro(armazena(num5, num6, num7, num8))), soma(quarto(armazena(num1, num2, num3, num4)), quarto(armazena(num5, num6, num7, num8))))))
		<< "(" << n1(bloco2(codificar(armazena(soma(primeiro(armazena(num1, num2, num3, num4)), primeiro(armazena(num5, num6, num7, num8))), soma(segundo(armazena(num1, num2, num3, num4)), segundo(armazena(num5, num6, num7, num8))), soma(terceiro(armazena(num1, num2, num3, num4)), terceiro(armazena(num5, num6, num7, num8))), soma(quarto(armazena(num1, num2, num3, num4)), quarto(armazena(num5, num6, num7, num8))))))) << " "
		<< n2(bloco2(codificar(armazena(soma(primeiro(armazena(num1, num2, num3, num4)), primeiro(armazena(num5, num6, num7, num8))), soma(segundo(armazena(num1, num2, num3, num4)), segundo(armazena(num5, num6, num7, num8))), soma(terceiro(armazena(num1, num2, num3, num4)), terceiro(armazena(num5, num6, num7, num8))), soma(quarto(armazena(num1, num2, num3, num4)), quarto(armazena(num5, num6, num7, num8))))))) << " "
		<< n3(bloco2(codificar(armazena(soma(primeiro(armazena(num1, num2, num3, num4)), primeiro(armazena(num5, num6, num7, num8))), soma(segundo(armazena(num1, num2, num3, num4)), segundo(armazena(num5, num6, num7, num8))), soma(terceiro(armazena(num1, num2, num3, num4)), terceiro(armazena(num5, num6, num7, num8))), soma(quarto(armazena(num1, num2, num3, num4)), quarto(armazena(num5, num6, num7, num8))))))) << " "
		<< n4(bloco2(codificar(armazena(soma(primeiro(armazena(num1, num2, num3, num4)), primeiro(armazena(num5, num6, num7, num8))), soma(segundo(armazena(num1, num2, num3, num4)), segundo(armazena(num5, num6, num7, num8))), soma(terceiro(armazena(num1, num2, num3, num4)), terceiro(armazena(num5, num6, num7, num8))), soma(quarto(armazena(num1, num2, num3, num4)), quarto(armazena(num5, num6, num7, num8))))))) << " "
		<< n5(bloco2(codificar(armazena(soma(primeiro(armazena(num1, num2, num3, num4)), primeiro(armazena(num5, num6, num7, num8))), soma(segundo(armazena(num1, num2, num3, num4)), segundo(armazena(num5, num6, num7, num8))), soma(terceiro(armazena(num1, num2, num3, num4)), terceiro(armazena(num5, num6, num7, num8))), soma(quarto(armazena(num1, num2, num3, num4)), quarto(armazena(num5, num6, num7, num8))))))) << " "
		<< n6(bloco2(codificar(armazena(soma(primeiro(armazena(num1, num2, num3, num4)), primeiro(armazena(num5, num6, num7, num8))), soma(segundo(armazena(num1, num2, num3, num4)), segundo(armazena(num5, num6, num7, num8))), soma(terceiro(armazena(num1, num2, num3, num4)), terceiro(armazena(num5, num6, num7, num8))), soma(quarto(armazena(num1, num2, num3, num4)), quarto(armazena(num5, num6, num7, num8)))))))
		<< ")" << endl;

	//Soma descriptografada
	cout << "Soma decodificada = " << decodificar(codificar(armazena(soma(primeiro(armazena(num1, num2, num3, num4)), primeiro(armazena(num5, num6, num7, num8))), soma(segundo(armazena(num1, num2, num3, num4)), segundo(armazena(num5, num6, num7, num8))), soma(terceiro(armazena(num1, num2, num3, num4)), terceiro(armazena(num5, num6, num7, num8))), soma(quarto(armazena(num1, num2, num3, num4)), quarto(armazena(num5, num6, num7, num8)))))) << endl;
	cout << endl;

	//Valor do bloco com os Bits mais altos e o n�mero das posi��es alteradas
	cout << "Valor codificado = " << bloco1(codificar(armazena(multi(primeiro(armazena(num1, num2, num3, num4)), primeiro(armazena(num5, num6, num7, num8))), multi(segundo(armazena(num1, num2, num3, num4)), segundo(armazena(num5, num6, num7, num8))), multi(terceiro(armazena(num1, num2, num3, num4)), terceiro(armazena(num5, num6, num7, num8))), multi(quarto(armazena(num1, num2, num3, num4)), quarto(armazena(num5, num6, num7, num8))))))
		<< "(" << n1(bloco2(codificar(armazena(multi(primeiro(armazena(num1, num2, num3, num4)), primeiro(armazena(num5, num6, num7, num8))), multi(segundo(armazena(num1, num2, num3, num4)), segundo(armazena(num5, num6, num7, num8))), multi(terceiro(armazena(num1, num2, num3, num4)), terceiro(armazena(num5, num6, num7, num8))), multi(quarto(armazena(num1, num2, num3, num4)), quarto(armazena(num5, num6, num7, num8))))))) << " "
		<< n2(bloco2(codificar(armazena(multi(primeiro(armazena(num1, num2, num3, num4)), primeiro(armazena(num5, num6, num7, num8))), multi(segundo(armazena(num1, num2, num3, num4)), segundo(armazena(num5, num6, num7, num8))), multi(terceiro(armazena(num1, num2, num3, num4)), terceiro(armazena(num5, num6, num7, num8))), multi(quarto(armazena(num1, num2, num3, num4)), quarto(armazena(num5, num6, num7, num8))))))) << " "
		<< n3(bloco2(codificar(armazena(multi(primeiro(armazena(num1, num2, num3, num4)), primeiro(armazena(num5, num6, num7, num8))), multi(segundo(armazena(num1, num2, num3, num4)), segundo(armazena(num5, num6, num7, num8))), multi(terceiro(armazena(num1, num2, num3, num4)), terceiro(armazena(num5, num6, num7, num8))), multi(quarto(armazena(num1, num2, num3, num4)), quarto(armazena(num5, num6, num7, num8))))))) << " "
		<< n4(bloco2(codificar(armazena(multi(primeiro(armazena(num1, num2, num3, num4)), primeiro(armazena(num5, num6, num7, num8))), multi(segundo(armazena(num1, num2, num3, num4)), segundo(armazena(num5, num6, num7, num8))), multi(terceiro(armazena(num1, num2, num3, num4)), terceiro(armazena(num5, num6, num7, num8))), multi(quarto(armazena(num1, num2, num3, num4)), quarto(armazena(num5, num6, num7, num8))))))) << " "
		<< n5(bloco2(codificar(armazena(multi(primeiro(armazena(num1, num2, num3, num4)), primeiro(armazena(num5, num6, num7, num8))), multi(segundo(armazena(num1, num2, num3, num4)), segundo(armazena(num5, num6, num7, num8))), multi(terceiro(armazena(num1, num2, num3, num4)), terceiro(armazena(num5, num6, num7, num8))), multi(quarto(armazena(num1, num2, num3, num4)), quarto(armazena(num5, num6, num7, num8))))))) << " "
		<< n6(bloco2(codificar(armazena(multi(primeiro(armazena(num1, num2, num3, num4)), primeiro(armazena(num5, num6, num7, num8))), multi(segundo(armazena(num1, num2, num3, num4)), segundo(armazena(num5, num6, num7, num8))), multi(terceiro(armazena(num1, num2, num3, num4)), terceiro(armazena(num5, num6, num7, num8))), multi(quarto(armazena(num1, num2, num3, num4)), quarto(armazena(num5, num6, num7, num8)))))))
		<< ")" << endl;

	//Multiplica��o descriptografada
	cout << "Mult decodificada = " << decodificar(codificar(armazena(multi(primeiro(armazena(num1, num2, num3, num4)), primeiro(armazena(num5, num6, num7, num8))), multi(segundo(armazena(num1, num2, num3, num4)), segundo(armazena(num5, num6, num7, num8))), multi(terceiro(armazena(num1, num2, num3, num4)), terceiro(armazena(num5, num6, num7, num8))), multi(quarto(armazena(num1, num2, num3, num4)), quarto(armazena(num5, num6, num7, num8)))))) << endl;

	





}	