#include <iostream>
#include "simd.h"
using namespace std;

//Recebe 4 valores e armazena em um bloco de 32 bits
int armazena(char a, char b , char c, char d)
{
	
	int teste, teste1 , teste2, teste3;
	teste1 = a;
	teste1 = teste1 << 24;

	teste2 = b;
	teste2 = teste2 << 16;
	
	teste3 = c;
	teste3 = teste3 << 8;

	teste = (teste1 + teste2 + teste3 + d);
	return teste;
} 

//Retorna o primeiro numero do xxm
int primeiro(unsigned int a)
{
	int primeiro = a;
	primeiro = primeiro >> 24;

	return char (primeiro);
}

//Retorna o segundo numero do xxm
int segundo(unsigned int a)
{
	int segundo = a;
	segundo = segundo >> 16;

	return char(segundo);
}

//Retorna o terceiro numero do xxm
int terceiro(unsigned int a)
{
	int terceiro = a;
	terceiro = terceiro >> 8;

	return char(terceiro);

}

//Seleciona o quarto numero do xxm
int quarto(unsigned int a)
{
	int quarto = a;
	
	return char(quarto);
}

//Recebe um numero de cada bloco de 32 bits e retorna a soma entre eles.
 int soma(int a, int b)
{
	char primeiro, segundo;
	 primeiro = a;
	primeiro = primeiro >> 24;
	segundo = b;
	segundo = segundo >> 24;
	int primeiros = (a + b);
	return primeiros;
}

 //Recebe um numero de cada bloco de 32 bits e retorna a multiplica��oe entre eles
 int multi(int a, int b)
 {
	 char primeiro, segundo;
	 primeiro = a;
	 primeiro = primeiro >> 24;
	 segundo = b;
	 segundo = segundo >> 24;
	 int primeirom = (a * b);
	 return primeirom;
 }