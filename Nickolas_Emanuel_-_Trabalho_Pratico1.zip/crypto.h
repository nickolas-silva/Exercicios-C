#include <iostream>
#include <stdlib.h>
#include <random>
using namespace std;

long long codificar(int);
unsigned int decodificar(long long);
unsigned int ligarbit(unsigned int, unsigned int);
unsigned int desligarbit(unsigned int, unsigned int);
unsigned int testarbit(unsigned int, unsigned int);
unsigned int bloco1(long long);
unsigned int bloco2(long long);
unsigned int n1(unsigned int);
unsigned int n2(unsigned int);
unsigned int n3(unsigned int);
unsigned int n4(unsigned int);
unsigned int n5(unsigned int);
unsigned int n6(unsigned int);

