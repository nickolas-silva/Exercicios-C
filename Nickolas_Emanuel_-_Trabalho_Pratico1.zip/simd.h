#pragma once
#include <iostream>
using namespace std;

int armazena(char, char, char, char);
int primeiro(unsigned int);
int segundo(unsigned int);
int terceiro(unsigned int);
int quarto(unsigned int);
int soma(int, int);
int multi( int, int);