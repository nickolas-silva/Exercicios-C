#include <iostream>
using namespace std;

struct tupla
{
	int a;
	int b;
	int c;
};

void Inverter(tupla &, tupla &);

int main()
{
	tupla a, b;
	a.a = 15;
	a.b = 20;
	a.c = 25;
	b.a = 40;
	b.b = 50;
	b.c = 60;
	cout << "Tupla A: " << a.a << " " << a.b << " " << a.c << endl;
	cout << "Tupla B: " << b.a << " " << b.b << " " << b.c << endl;
	cout << endl;
	cout << "Invertendo...\n\n";
	Inverter(a, b);

}
void Inverter(tupla& a, tupla & b)
{
	tupla x = b;
	b = a;
	a = x;
	cout << "Tupla A: " << a.a << " " << a.b << " " << a.c << endl;
	cout << "Tupla B: " << b.a << " " << b.b << " " << b.c << endl;

	
}