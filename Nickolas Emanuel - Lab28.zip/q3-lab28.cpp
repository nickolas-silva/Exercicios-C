#include <iostream>
#include <fstream>
using namespace std;


struct par
{
	int x;
	int y;
};
ostream& operator<<(ostream& os, par& teste);

int main()
{
	par x;
	ofstream fout;
	ifstream fin;

	fin.open("pares.txt");
	cout << "Pares: ";
	while (fin.good())
	{
		fin >> x.x;
		fin >> x.y;
		cout << x;
	}
	fin.close();
}
ostream& operator<<(ostream& os, par& teste)
{
	os << "[";
	os << teste.x;
	os << ",";
	os << teste.y;
	os << "] ";
	return os;
}