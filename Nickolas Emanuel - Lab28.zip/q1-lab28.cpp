#include <iostream>
using namespace std;

void TempodaVolta(float);
static float Temp = 0;
int main()
{
	while (cin.good())
	{
		float time;
		cout << "Volta: ";
		cin >> time;
		TempodaVolta(time);
	}

}
void TempodaVolta(float t)
{
	Temp += t;
	cout << "Tempo total = " << Temp << " segs. " << endl;
}