#include <iostream>
using namespace std;

int main()
{
	const char* meses[12] =
	{ "Janeiro", "Fevereiro", "Mar�o", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro",
		"Outubro", "Novembro", "Dezembro"};

	int i = 0;
	int j = 0;
	int t1 = 0;
	int t2 = 0;
	int t3 = 0;
	int tt = 0;


	int vd[3][12];
	for (j = 0; j < 3; j++)
	{
		cout << "Digite o numero de livros vendidos no " << (j+1) << "�ano: " << endl;
		for (i = 0; i < 12; i++)
		{
			cout << meses[i] << ":";
			cin >> vd[j][i];

			
		}
		cout << endl;
	}
	for (i = 0; i < 12; i++)
	{
		t1 += vd[0][i];
		t2 += vd[1][i];
		t3 += vd[2][i];

	}
	cout << endl;
	cout << "Total de vendas:" << endl;
	cout << "Primeiro ano: " << t1 << endl;
	cout << "Segundo ano: " << t2 << endl;
	cout << "Terceiro ano: " << t3 << endl;
	cout << endl << "Nos tres anos foram vendidos " << (t1 + t2 + t3) << " livros.";


}