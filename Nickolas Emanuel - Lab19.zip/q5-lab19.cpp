#include <iostream>
using namespace std;

int main()
{
	int mat[16][16];
	int i, j, cont=0;
	int l1, l2, cl1, cl2;
	char pontos;
	int linhas, colunas;

	for (j = 0; j < 16; j++)
	{
		for (i = 0; i < 16; i++)
		{
			mat[i][j] = cont;

			++cont;
		}
	}
	cout << "Entre com as coordenadas da regiao de interesse" << endl;
	cout << "De: ";
	cin >> pontos >> l1 >> pontos >> cl1 >> pontos;
	cout << "Ate: ";
	cin >> pontos >> l2 >> pontos >> cl2 >> pontos;

	linhas = (l2 - l1) + 1;
	colunas = (cl2 - cl1) + 1;

	int** matd = new int* [linhas];

	for (int i = 0; i < linhas; ++i)
		matd[i] = new int[colunas];

	for (int j = 0; j < linhas; ++j)
		for (int i = 0; i < colunas; ++i)
			matd[i][j] = mat[i][j];

	for (j = l1; j < l2; j++)
	{
		for (i = cl1; i < cl2; i++)
		{
			cout << char(mat[i][j]) << " ";
			cout << endl;
			
		}
		
	}
	for (int i = 0; i < linhas; ++i)
		delete[] matd[i];
	delete[] matd;
}