#include <iostream>
using namespace std;

int main()
{
	int cl = 0;
	int mat[4][4] =
	{
	   {3, 1, 5, 5},    
	   {1, 5, 5, 6},    
	   {2, 3, 4, 5},    
	   {4, 9, 1, 8}     
	};
	cout << "A soma das colunas �: ";
	for (int i = 0; i < 4; i++)
	{
		cl = 0;
		for (int j = 0; j < 4; j++)
		{
			cl += mat[j][i];
		}
		cout << cl << " ";
	}
}