#include <iostream>
using namespace std;

long long calculo(long long, long long);

int main()
{


	long long resultado =  200530LL * 420800;
	//AO INDICAR O TAMANHO DA VARI�VEL EM UM DOS VALORES, O PROGRAMA PODE RESERVAR O TAMANHO DE ESPA�O ADEQUADO PARA COMPORTAR O TAMANHO DO RESULTADO
	cout << "Direto: " << resultado << endl;
	cout << "Fun��o: " << calculo(200530, 420800) << endl;
	return 0;
}
long long calculo(long long a, long long b)
{
	return a * b;
}