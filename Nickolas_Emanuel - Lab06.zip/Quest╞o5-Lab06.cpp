#include <iostream>
#include <climits>
using namespace std;
bool isShort(long long);
bool isInt(long long);

int main()
{
	long long num;
	
	cout << "Digite um valor inteiro: ";
	cin >> num;
	 
	if (isShort(num) == false)
	{
		cout << num << " nao cabe em 16 bits" << endl;
	}
	else
	cout << num << " cabe em 16 bits" << endl;
		
	if (isInt(num) == false)
	{
		cout << num << " nao cabe em 32 bits";
	}
	else
	cout << num << " cabe em 32 bits";
		
}
bool isShort(long long a)
{
	bool b;
	if (a > SHRT_MAX)
	{
		b = false;
			return b;
	}
	else
		b = true;
		return b;
}
bool isInt(long long a)
{
	bool b;
	if (a > INT_MAX)
	{
		b = false;
			return b;
	}
	else
		b = true;
		return b;
}