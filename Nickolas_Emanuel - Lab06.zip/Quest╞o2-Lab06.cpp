#include <iostream>
using namespace std;

int main()
{
	cout << "P�es&Cia" << endl;

	int quantpao, quantpas;

	cout << "Quantos p�es? ";
	cin >> quantpao;

	cout << "Quantos pasteis? ";
	cin >> quantpas;
	
#define pao 0.30;
#define pastel 0.25;
	
	
	float pfpao = quantpao * pao;
	float pfpas = quantpas * pastel;

	cout << "O total das compras � R$" << (pfpao + pfpas) << endl;






}