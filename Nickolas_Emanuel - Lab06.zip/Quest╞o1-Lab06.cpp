#include <iostream>
using namespace std;

int main()
{
	int h1, h2, m1, m2, hf, mf;
	char pontos;

	cout << "Digite o hor�rio de partida (HH:MM): ";//ENTRADA DO HOR�RIO DE PARTIDA
	cin >> h1;
	cin >> pontos;
	cin >> m1;

	cout << "Digite o hor�rio de chegada (HH:MM): "; //ENTRADA DO HOR�RIO DE CHEGADA
	cin >> h2;
	cin >> pontos;
	cin >> m2;
	cout << "\n";
	//C�LCULO DAS HORAS E MINUTOS FINAIS
	hf = (h2 - h1);
	mf = (m2 - m1);
	if (mf < 0)//C�LCULO DA DIFEREN�A ENTRE OS HOR�RIOS
	{
		hf = hf - 1;
		mf = mf + 60;
	}
		
	else
	{

	}
	cout << "O tempo total de viagem foi de " << hf << " horas e " << mf << " min.";//SA�DA DO PROGRAMA

}