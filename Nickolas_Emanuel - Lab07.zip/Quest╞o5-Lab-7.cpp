#include <iostream>
using namespace std;
//Prot�tipo das fun��es
void exibirBits(unsigned char);
bool testarBit(unsigned char, int);

int main()
{
	//Leitura do valor a ser convertido
	int num1;
	cout << "Digite um valor entre 0 e 255: ";
	cin >> num1;
	unsigned char num = num1;

	//Saida do resultado
	cout << "O numero " << num << " em bin�rio � "; 
	exibirBits(num);


}
void exibirBits(unsigned char a)//Fun��o para retornar o valor dos bits
{
	cout << testarBit(a, 7);
	cout << testarBit(a, 6);
	cout << testarBit(a, 5);
	cout << testarBit(a, 4);
	cout << testarBit(a, 3);
	cout << testarBit(a, 2);
	cout << testarBit(a, 1);
	cout << testarBit(a, 0);
	

}
bool testarBit(unsigned char a, int bit)//Fun��o para testar os bits
{
	if (a & (1 << bit))
		return true;
	else
		return false;
}