#include <iostream>
using namespace std;
//Prototipo das fun��es
char codificar(char);
char decodificar(char);

int main()
{
	//Entrada do caractere
	char ch;
	cout << "Digite um caractere: ";
	cin >> ch;

	//Chamada das fun��es
	cout << "O caractere codificado: " << codificar(ch) << endl;
	ch = codificar(ch);
	cout << "O caractere decodificado: " << decodificar(ch) << endl;

}
char codificar(char a) //Fun��o que codifica o caractere
{
	a = a + 3;
	return a;
}
char decodificar(char b) //Fun��o que decodifica o caractere
{
	b = b - 3;
	return b;

}