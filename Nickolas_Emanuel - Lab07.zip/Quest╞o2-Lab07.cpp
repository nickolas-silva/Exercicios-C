#include <iostream>
using namespace std;

//Prot�tipo das fun��es
char codificar(char);
char decodificar(char);

int main()
{
	//Entrada da letra
	char ch;
	cout << "Digite uma letra: ";
	cin >> ch;

	//Entrada da resposta do usu�rio
	int resposta;
	cout << "Digite 1 para codificar\n" << "Digite 0 para decodificar\n";
	cin >> resposta;

	//Condi��o para codificar ou decodificar
	if (resposta == true)
		cout << codificar(ch);
	else
		cout << decodificar(ch);
	
}
char codificar(char a)//Fun��o para codificar
{
	a = a + 3;
	return a;
}
char decodificar(char a)//Fun��o para decodificar
{
	a = a - 3;
	return a;
}