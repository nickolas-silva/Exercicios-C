#include <iostream>
using namespace std;
//Prot�tipo da fun��o
int bitsBaixos(unsigned int);

int main()
{
	//Entrada do valor
	cout << "Digite um valor inteiro: ";
	unsigned int valor;
	cin >> valor;
	//Saida do programa
	cout << "Os 16 bits mais baixos desse valor correspondem ao numero " << bitsBaixos(valor) << endl;

}
int bitsBaixos(unsigned int a)//Fun��o que mostra os bits mais baixos
{
	unsigned int mascara = a & ((1 << 16) - 1);
	return mascara;
}