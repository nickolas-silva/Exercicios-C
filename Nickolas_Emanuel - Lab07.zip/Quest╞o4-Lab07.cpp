#include <iostream>
using namespace std;
//Prot�tipo da fun��o
int bitsAltos(unsigned int);

int main()
{
	//Leitura do valor
	cout << "Digite um valor inteiro: ";
	unsigned int valor;
	cin >> valor;
	//Saida do programa
	cout << "Os 16 bits mais altos desse valor correspondem ao numero " << bitsAltos(valor) << endl;

}
int bitsAltos(unsigned int a)//Fun��o que indentifica os bits mais altos
{
	unsigned int mascara = ~((1 << 16)-1);
	unsigned int estado = (a & mascara) ;
	estado = estado >> 16;
	return estado;
	
}