#include <iostream>
#include <fstream>
using namespace std;

union Senha
{
	char Alphanum[25];
	char numerica[25];
};

int main()
{
	Senha password;

	int val = 0;
	char ch;
	cout << "Deseja exibir a senha[A] ou criar uma nova[B]? ";
	cin >> ch;

	ofstream fout;
	ifstream fin;
	fin.open("senha.dat", ios_base::in | ios_base::binary);

	if (ch == 'A')
	{
		if (!fin.is_open())
			cout << "Arquivo inexistente!";
		else
		{
		
			fin.read((char*)&password, sizeof(Senha));
			cout << password.Alphanum;
		}

	}
	else if (ch == 'B')
	{
		fout.open("senha.dat", ios_base::out | ios_base::binary);
		cout << "Senha Alfanumerica[1] ou senha Numerica[2]: ";
		cin >> val;

		if (val == 1)
		{
			cout << "Digite a senha Alphanumerica:";
			cin >> password.Alphanum;
			fout.write((char*)&password, sizeof(Senha));
		}

		if (val == 2)
		{
			cout << "Digite a senha numerica: ";
			cin >> password.numerica;
			fout.write((char*)&password, sizeof(Senha));

		}
	}
	fin.close();
	fout.close();
}