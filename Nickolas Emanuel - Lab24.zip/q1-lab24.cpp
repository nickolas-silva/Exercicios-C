#include <iostream>
#include <fstream>
using namespace std;

int main()
{
	ofstream fout;
	fout.open("teste.txt");
	
	int numn[100];
	for (int i = 0; i < 100; i++)
	{
		numn[i] = i;
		fout << numn[i] << endl;
		if (i % 5 == 0)
			fout << endl;
		
	}
	fout.close();

	fout.open("teste_m.dat", ios_base::out | ios_base::binary);

	for (int i = 0; i < 100; i++)
	{
		fout.write((char *) &numn[i], 100);
	}
	fout.close();

	int numt[100];
	ifstream fin;
	fin.open("teste_m.dat", ios_base::in | ios_base::binary);
	for (int j = 0; j<100; j++)
		fin.read((char* ) &numt[j], 100);
	for (int j = 0; j<100; j++)
		cout << numt[j] << endl;
}
