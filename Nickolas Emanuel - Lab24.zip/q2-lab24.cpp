#include <iostream>
#include <fstream>
using namespace std;

char menu(void);

struct Soldado
{
	char nick[20];
	int kills;
	int deads;
	float kd;
	int matchs;
};

void exibe(Soldado);

int main()
{
	Soldado at;

	ifstream fin;
	ofstream fout;
	fin.open("soldados.dat", ios_base::in | ios_base::binary);

	if (fin.read((char *) &at, sizeof(Soldado)))
	{
		switch (menu())
		{
		case 'n':
		case 'N': cout << "Entre com o nome do Soldado: ";
			cin >> at.nick;
			cout << "Entre as elimnina��es do Soldado: ";
			cin >> at.kills;
			cout << "Entre com as mortes do Soldado: ";
			cin >> at.deads;
			at.kd = (at.kills / at.deads);
			cout << "Entre com as partidas jogadas do Soldado: ";
			cin >> at.matchs;
			fout.open("soldados.dat", ios_base::out | ios_base::binary | ios_base::trunc);
			fout.write((char*)&at, sizeof(Soldado));
			break;

		case 'a':
		case 'A': cout << "Entre com as eliminacoes do Soldado";
			cin >> at.kills;
			cout << "Entre com as mortes do Soldado";
			cin >> at.deads;
			at.kd = (at.kills / at.deads);
			at.matchs += 1;
			break;

		case 'e':
		case 'E': exibe(at);
			break;

		case 's':
		case 'S': break;
		}

	}
	else
	{
		cout << "Entre com o nome do Soldado: ";
		cin >> at.nick;
		cout << "Entre as elimnina��es do Soldado: ";
		cin >> at.kills;
		cout << "Entre com as mortes do Soldado: ";
		cin >> at.deads;
		at.kd = (at.kills / at.deads);
		cout << "Entre com as partidas jogadas do Soldado: ";
		cin >> at.matchs;
		fout.open("soldados.dat", ios_base::out | ios_base::binary | ios_base::trunc);
		fout.write((char*)&at, sizeof(Soldado));
	}
	fin.close();
	fout.close();
}
char menu(void)
{
	char escolha;
	cout << "[N]ovo Soldado (sobrescreve o anterior)\n";
	cout << "[A]tualiza o Soldado (com os dados da ultima partida)\n";
	cout << "[E]xibe soldado (atual)\n";
	cout << "[S]air\n";

	cin >> escolha;
	return escolha;
}
void exibe(Soldado at)
{
	cout << "Nome: " << at.nick << endl;
	cout << "Eliminacoes: " << at.kills << endl;
	cout << "Mortes: " << at.deads << endl;
	cout << "KD: " << at.kd << endl;
	cout << "Partidas Jogadas: " << at.matchs << endl;
}